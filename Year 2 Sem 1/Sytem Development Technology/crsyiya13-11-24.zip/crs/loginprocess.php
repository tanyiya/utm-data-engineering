<?php
session_start();

//connect to DB
include('db-connect.php');

//Retrieve data from form
$funame = $_POST['funame'];
$fpwd = $_POST['fpwd'];


//SQL Retrieve Operation to get user data from db(login)
$sql = "SELECT * FROM tb_user
        WHERE u_sno= '$funame' AND u_pwd= '$fpwd'";

//execute SQL
$result= mysqli_query($con, $sql);
//Retrieve data
$row= mysqli_fetch_array($result);
//count result to check
$count= mysqli_num_rows($result);

//Rule-based AI login
if($count == 1) //check if user exist
{
   //set session
   $_SESSION['u_sno'] = session_id();
   $_SESSION['funame'] = $funame;
 if ($row['u_utype'] == 1) //check user type
 {
    //direct to lecturer page
   header('Location: lecturer.php');
    
 }
 if ($row['u_utype'] == 2) //check user type
 {
    //direct to Student page
   header('Location: student.php');

 }
 if ($row['u_utype'] == 3) //check user type
 {
    //direct to IT staff page
   header('Location: staff.php');

 }
}

else
{
   // redirect to login error page (individual project)
   header('Location: login.php'); //temporary redirect page
}

//close connection
mysqli_close($con);

//confirmation registration successful or fail (individual project)


?>