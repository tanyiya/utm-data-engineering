<?php include 'headermain.php';?>

<div class="container">
  <br><h5> Please fill in all the details below.</h5>
<form method = "post" action = "registerprocess.php">
  <fieldset>
    <div>
      <label class="form-label mt-4">Please enter your staff or student number.</label>
      <input type="text" name= "funame" class="form-control" aria-describedby="emailHelp" placeholder="Staff ID/Student ID" required>

    </div>
    <div>
      <label class="form-label mt-4">Create your password</label>
      <input type="password" name= "fpwd" class="form-control" placeholder="Password" autocomplete="off" required>
    </div>
    <div>
    <label class="form-label mt-4">Email address</label>
      <input type="email" name= "femail" class="form-control" aria-describedby="emailHelp" placeholder="Enter email" required>
      <!--<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
    </div>

    <div>
      <label class="form-label mt-4">Enter your full name.</label>
      <input type="text" name= "fname" class="form-control" aria-describedby="emailHelp" placeholder="Full Name as per NRIC" required>

    </div>

    <div>
      <label class="form-label mt-4">Enter your contact number.</label>
      <input type="number" name= "fcontact" class="form-control" aria-describedby="emailHelp" placeholder="Contact Number" required>

    </div>
    <div>
      <label class="form-label mt-4">Select your state.</label>
      <select class="form-select" name= "fstate">
        <option>Johor</option>
        <option>Kedah</option>
        <option>Kelantan</option>
        <option>Malacca</option>
        <option>Negeri Sembilan</option>
        <option>Pahang</option>
        <option>Penang</option>
        <option>Perak</option>
        <option>Perlis</option>
        <option>Selangor</option>
        <option>Terengganu</option>
        <option>Sabah</option>
        <option>Sarawak</option>
        <option>Wilayah Persekutuan Kuala Lumpur</option>
        <option>Wilayah Persekutuan Labuan</option>
        <option>Wilayah Persekutuan Putrajaya</option>

      </select>
    </div>
    <!--<div>
      <label for="exampleSelect1" class="form-label mt-4">Example disabled select</label>
      <select class="form-select" id="exampleDisabledSelect1" disabled="">
        <option>1</option>
        <option>2</option>
        <option>3</option>
        <option>4</option>
        <option>5</option>
      </select>
    </div>
    <div>
      <label for="exampleSelect2" class="form-label mt-4">Example multiple select</label>
      <select multiple="" class="form-select" id="exampleSelect2">
        <option>1</option>
        <option>2</option>
        <option>3</option>
        <option>4</option>
        <option>5</option>
      </select>
    </div>
    <div>
      <label for="exampleTextarea" class="form-label mt-4">Example textarea</label>
      <textarea class="form-control" id="exampleTextarea" rows="3"></textarea>
    </div>
    <div>
      <label for="formFile" class="form-label mt-4">Default file input example</label>
      <input class="form-control" type="file" id="formFile">
    </div>
    <fieldset>
      <legend class="mt-4">Radio buttons</legend>
      <div class="form-check">
        <input class="form-check-input" type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked="">
        <label class="form-check-label" for="optionsRadios1">
          Option one is this and that—be sure to include why it's great
        </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="radio" name="optionsRadios" id="optionsRadios2" value="option2">
        <label class="form-check-label" for="optionsRadios2">
          Option two can be something else and selecting it will deselect option one
        </label>
      </div>
      <div class="form-check disabled">
        <input class="form-check-input" type="radio" name="optionsRadios" id="optionsRadios3" value="option3" disabled="">
        <label class="form-check-label" for="optionsRadios3">
          Option three is disabled
        </label>
      </div>
    </fieldset>
    <fieldset>
      <legend class="mt-4">Checkboxes</legend>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
        <label class="form-check-label" for="flexCheckDefault">
          Default checkbox
        </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" checked="">
        <label class="form-check-label" for="flexCheckChecked">
          Checked checkbox
        </label>
      </div>
    </fieldset>
    <fieldset>
      <legend class="mt-4">Switches</legend>
      <div class="form-check form-switch">
        <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault">
        <label class="form-check-label" for="flexSwitchCheckDefault">Default switch checkbox input</label>
      </div>
      <div class="form-check form-switch">
        <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" checked="">
        <label class="form-check-label" for="flexSwitchCheckChecked">Checked switch checkbox input</label>
      </div>
    </fieldset>
    <fieldset>
      <legend class="mt-4">Ranges</legend>
        <label for="customRange1" class="form-label">Example range</label>
        <input type="range" class="form-range" id="customRange1">
        <label for="disabledRange" class="form-label">Disabled range</label>
        <input type="range" class="form-range" id="disabledRange" disabled="">
        <label for="customRange3" class="form-label">Example range</label>
        <input type="range" class="form-range" min="0" max="5" step="0.5" id="customRange3">
    </fieldset>-->
    <br><br>
    <button type="submit" class="btn btn-primary">Submit</button>
    <button type="reset" class="btn btn-danger">Clear Form</button>

    <br><br><br><br>
  </fieldset>
</form>


</div>

<?php include 'footer.php';?>