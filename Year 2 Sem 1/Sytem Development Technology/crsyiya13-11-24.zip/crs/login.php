<?php include 'headermain.php';?>

<div class="container">
  <br><h4> Log In</h4>
<form method = "post" action = "loginprocess.php">
  <fieldset>
  <div>
  <label class="form-label mt-4">Username</label>
  <div class="form-floating mb-3">
    <input type="text" name= "funame" class="form-control" id="floatingInput" placeholder="Staff ID/Student ID" required>
    <label for="floatingInput">Staff ID/Student ID</label>
  </div>
  <div class="form-floating">
    <input type="password" name= "fpwd" class="form-control" id="floatingPassword" placeholder="Password" autocomplete="off" required>
    <label for="floatingPassword">Password</label>
  </div>
</div>
    <!--<div>
      <label class="form-label mt-4">Username</label>
      <input type="text" name= "funame" class="form-control" aria-describedby="emailHelp" placeholder="Staff ID/Student ID" required>

    </div>
    <div>
      <label class="form-label mt-4">Password</label>
      <input type="password" name= "fpwd" class="form-control" placeholder="Password" autocomplete="off" required>
    </div>-->
    
    <br><br>
    <button type="submit" class="btn btn-primary">Login</button>

    <br><br><br><br>
  </fieldset>
</form>


</div>

<?php include 'footer.php';?>