<?php 
include('crs_session.php');
if(!session_id())
{
    session_start();
}

include 'headerlec.php';
?>

<div class="container">
    <br>
Lecturer page
</div>

<?php include 'footer.php';?>