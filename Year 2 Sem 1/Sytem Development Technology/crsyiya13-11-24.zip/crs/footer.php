<!DOCTYPE html>
<html lang="en">
<head>
  <title>Course Registration System</title>
  <link rel="icon" type="image/x-icon" href="img/kuromi.ico">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: #2c3e50;
   color: white;
   text-align: center;
}
</style>
</head>
<body>



<div class= "footer">
<p>Developed by Tan Yi Ya @2024</p>
</div>

</body>
</html>