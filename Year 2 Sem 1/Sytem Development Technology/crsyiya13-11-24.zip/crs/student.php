<?php 
include('crs_session.php');
if(!session_id())
{
    session_start();
}

include 'headerstu.php';?>

<div class="container">
    <br>
Student page
</div>

<?php include 'footer.php';?>