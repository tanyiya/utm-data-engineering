<?php 
include('crs_session.php');
if(!session_id())
{
    session_start();
}


include 'headerit.php';?>

<div class="container">
    <br>
IT Staff page
</div>

<?php include 'footer.php';?>