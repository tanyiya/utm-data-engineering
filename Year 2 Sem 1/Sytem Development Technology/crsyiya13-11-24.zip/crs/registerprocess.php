<?php
//connect to DB
include('db-connect.php');

//Retrieve data from form
$funame = $_POST['funame'];
$fpwd = $_POST['fpwd'];
$femail = $_POST['femail'];
$fname = $_POST['fname'];
$fcontact = $_POST['fcontact'];
$fstate = $_POST['fstate'];

//SQL Insert Operation (register)
$sql = "INSERT INTO tb_user(u_sno, u_pwd, u_email, u_name, u_contact, u_state, u_req, u_utype)
        VALUES('$funame','$fpwd','$femail','$fname','$fcontact','$fstate', CURRENT_TIMESTAMP(), '2')";

//execute SQL
mysqli_query($con, $sql);

//close connection
mysqli_close($con);

//confirmation registration successful or fail (individual project)

//redirect user to login page
header('Location: login.php');

?>