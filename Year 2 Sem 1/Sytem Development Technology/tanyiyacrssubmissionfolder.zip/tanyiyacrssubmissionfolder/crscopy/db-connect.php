<?php 
//Set DB Parameter
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_crs1";

//Connect DB
$con = mysqli_connect($servername, $username, $password, $dbname);

//Connection Check (continue as individual project)

?>