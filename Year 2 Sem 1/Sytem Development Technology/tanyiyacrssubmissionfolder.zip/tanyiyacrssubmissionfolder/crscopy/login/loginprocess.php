<?php
session_start();
include('../db-connect.php');
include('loginfunction.php');
if ($con) {
   include('index.php');
} else {
    echo "Failed to connect to the database.";
}
$selectCurrentSem = "SELECT MAX(sem_id) FROM tb_sem;";
$result = mysqli_query($con, $selectCurrentSem);
$row = mysqli_fetch_assoc($result);
$_SESSION['current_sem'] = $row['MAX(sem_id)'];

if ($_POST){
   $cleanPost = cleanPost($_POST);

   $funame = $cleanPost['funame'];
   $fpwd = $cleanPost['fpwd'];  
   if(empty($errors)){
       $sql = "SELECT * FROM tb_user WHERE u_sno = ?";
       $stmt = mysqli_prepare($con, $sql);
       mysqli_stmt_bind_param($stmt, 's', $funame);  
       mysqli_stmt_execute($stmt);
       $result = mysqli_stmt_get_result($stmt);
       $user = mysqli_fetch_assoc($result);
       $matches = false;
      

       if($user){
           $matches = password_verify($fpwd, $user['u_pwd']);

           if($matches){
               // Successful login - Set session and redirect
               $_SESSION['u_sno'] = $user['u_sno']; 
               $_SESSION['funame'] = $user['funame'];
               $_SESSION['u_utype'] = $user['u_utype'];

               // Redirect based on user type
               if ($user['u_utype'] == 1) { // Lecturer
                   header('Location: ../lecturer');
                   exit;
               } else if ($user['u_utype'] == 2) { // Student
                   header('Location: ../student');
                   exit;
               } else if ($user['u_utype'] == 3) { // Admin
                  header('Location: ../admin');
                  exit;
              }
           }

           else {
               echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
                     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
                     <script>
                         Swal.fire({
                             icon: "error",
                             title: "Log In Failed.",
                             text: "Wrong User ID or Password",
                             footer: "<a href=\'../forgotpassword\'>Forgot Password?</a>"
                         });
                     </script>';
                     exit; 
           }
       }
       else echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
       <script>
           Swal.fire({
               icon: "error",
               title: "Log In Failed.",
               text: "User ID does not exist.",
           });
       </script>';
       exit; 
       
   }
}


mysqli_close($con);
?>

