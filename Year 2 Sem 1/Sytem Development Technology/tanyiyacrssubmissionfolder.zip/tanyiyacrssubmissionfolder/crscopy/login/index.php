<?php include 'header.php';?>

<body class="auth-body">
    <div class="auth-container">
        <div class="auth-wrapper">
            <div class="auth-form-container" id="login-container">
                <form method="post" class= "auth-form" action = "loginprocess.php">
                    <h2>Student Portal Login</h2>
                    <div class="form-group">
                        <label>User ID</label>
                        <input type="text" id="funame" name="funame" placeholder="Staff ID/Student ID" required>
                    </div>
                    <div class="form-group password-group">
                        <label for="login-password">Password</label>
                        <input type="password" id="fpwd" name="fpwd" placeholder="Password" autocomplete="off" required>
                    </div>
                    <button type="submit" class="auth-submit-btn">Login</button>
                    <a href="../forgotpassword" class="forgot-password-link">Forgot Password?</a>
                    <div class="auth-switch">
                        <p>Don't have an account?</p>
                        <button type="button" class="switch-btn" onclick="location.href='../register'">Register</button>
                    </div>
                </form>
            </div>          
        </div>
    </div>
</body>

