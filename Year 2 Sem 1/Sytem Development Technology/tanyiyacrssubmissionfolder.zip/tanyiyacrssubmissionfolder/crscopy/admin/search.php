<?php
include('../db-connect.php');

if (isset($_POST['input'])) {
    $input = mysqli_real_escape_string($con, $_POST['input']);

    // Query to fetch students and their registered courses
    $query = "
        SELECT *
        FROM tb_student s       
        WHERE s.s_no LIKE '{$input}%' 
        OR s.s_name LIKE '{$input}%'
    ";

    $result = mysqli_query($con, $query);

    if (mysqli_num_rows($result) > 0) { ?>
        <table class="table table-bordered table-striped mt-4">
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Contact</th>
                    <th>State</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr class="student-row" data-id="<?php echo $row['s_no']; ?>">
                        <td><?php echo $row['s_no']; ?></td>
                        <td><?php echo $row['s_name']; ?></td>
                        <td><?php echo $row['s_contact']; ?></td>
                        <td><?php echo $row['s_state']; ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
   
    <?php
    } else {
        echo "<h6 class='text-danger'>No data found</h6>";
    }
}
?>
