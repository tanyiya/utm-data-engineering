<?php
include('../login/loginfunction.php');
include('../db-connect.php');
session_start();
if ($con) {
    include 'coursearchive.php';
} else {
    echo "Failed to connect to the database.";
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cleanPost = cleanPost($_POST);
    $c_code = mysqli_real_escape_string($con, $cleanPost['code']);
    $c_lec = mysqli_real_escape_string($con, $cleanPost['lecturer']);
    $c_section = mysqli_real_escape_string($con, $cleanPost['section']);
    $c_maxstudent = mysqli_real_escape_string($con, $cleanPost['maxstudents']);
    $c_tid = mysqli_real_escape_string($con, $cleanPost['tid']);

    // Fetch existing data to check if the course section exists
    $query = "SELECT * FROM tb_offeredcourse WHERE c_id = '$c_tid'";
    $result = mysqli_query($con, $query);
    $course = mysqli_fetch_assoc($result);

    if (!$course) {
        echo "<script>
                Swal.fire({
                    title: 'Error!',
                    text: 'Course section not found!',
                    icon: 'error',
                    confirmButtonText: 'OK'
                }).then(() => { window.location.href = 'coursearchive.php'; });
              </script>";
        exit;
    }

    // Update the course section in the database
    if (isset($_POST['update'])) {
        $update_query = "UPDATE tb_offeredcourse SET c_lec = '$c_lec', c_section = '$c_section', c_maxstudent = '$c_maxstudent' WHERE c_id = '$c_tid'";

        if (mysqli_query($con, $update_query)) {
            echo "<script>
                    Swal.fire({
                        title: 'Success!',
                        text: 'Course section updated successfully!',
                        icon: 'success',
                        confirmButtonText: 'OK'
                    }).then(() => { window.location.href = 'coursearchive.php'; });
                  </script>";
        } else {
            echo "<script>
                    Swal.fire({
                        title: 'Error!',
                        text: 'Error: " . mysqli_error($con) . "',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                  </script>";
        }
    }
}
?>
