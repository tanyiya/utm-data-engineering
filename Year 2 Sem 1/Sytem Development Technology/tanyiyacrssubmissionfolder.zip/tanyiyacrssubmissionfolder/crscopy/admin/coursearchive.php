<?php
include('headeradmin.php');
include('../db-connect.php');

?>
<main class="dashboard-main">
            <section class="assigned-courses-section">
                <h4 style="margin-left: 8px">All Courses</h4>
                <div class="semester-filter">
                    <select id="semester-select">
                    <?php
                    $semester_query = "SELECT * FROM tb_sem";
                    $semester_result = mysqli_query($con, $semester_query);

                    while ($semester = mysqli_fetch_assoc($semester_result)) {
                        $selected = (isset($_GET['filter_semester']) && $_GET['filter_semester'] == $semester['sem_id']) ? 'selected' : '';
                        echo "<option value='{$semester['sem_id']}' $selected>{$semester['semester']}</option>";
                    }
                    ?>
                    </select>
                </div>
                <div id="course-list" class="course-list">
                    <!-- Courses -->
                </div>
            </section>

            <section class="course-details-section" id="course-details-section">
                <h5 style="margin-left: 8px">Select a course to see course details.</h5>
                <!-- Course explaination -->
            </section>
</main>

<script src="app.js"></script>