<?php
include('headeradmin.php');
include('../login/loginfunction.php');
include('../db-connect.php');
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $course = array(
        "code" => $_POST['code'] ?? '',
        "name" => $_POST['name'] ?? '',
        "description" => $_POST['description'] ?? '',
        "credits" => $_POST['credits'] ?? '',
        "section" => $_POST['section'] ?? '',
        "lecturer" => $_POST['lecturer'] ?? '',
        "tid" => $_POST['tid'] ?? ''
    );
}
?>

<div style="overflow-y: auto; height: 90vh;">
    <div class="add-course-container">
        <h2>Modify Course Section</h2>
        <form method="POST" action="modifycoursesectionaction.php">
        <input type="hidden" name="tid" value="<?php echo $course['tid']; ?>">
            <div class="form-group-readonly">  
                <label>Course</label>
                <input type="text" id="coursecode" name="code" value="<?php echo $course['code']; ?>" readonly>
                </select>
            </div>

            <div class="form-group-readonly">  
                <label>Course Name</label>
                <input type="text" id="coursename" name="name" value="<?php echo $course['name']; ?>" readonly>
                </select>
            </div>

            <div class="form-group">  
                <label>Section</label>
                <input type="text" id="coursesection" name="section" value="<?php echo $course['section']; ?>" required>
                </select>
            </div>
            
            <div class="form-group">
                <label for="lecturer-select">Select Lecturer</label>
                <select id="lecturer-select" name="lecturer" required>
                    <option value="" disabled>Select Lecturer</option>
                    <?php
                    $lecturer_query = "SELECT * FROM tb_lecturer";
                    $lecturer_result = mysqli_query($con, $lecturer_query);
                    while ($lecturer = mysqli_fetch_assoc($lecturer_result)) {
                        // Compare lecturer ID from the database with the selected one in $course['lecturer']
                        $selected = ($lecturer['l_name'] == $course['lecturer']) ? 'selected' : '';
                        echo "<option value='{$lecturer['l_no']}' $selected>{$lecturer['l_name']}</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label for="max-students">Maximum Students</label>
                <input type="number" id="max-students" name="maxstudents" min=10" value="<?php echo $course['section']; ?>" placeholder="Enter maximum number of students" required>
            </div>

            <button type="submit" name="update" class="add-course-btn">Update Course Section</button>
        </form>
    </div>
</div>

<script src="app.js"></script>
