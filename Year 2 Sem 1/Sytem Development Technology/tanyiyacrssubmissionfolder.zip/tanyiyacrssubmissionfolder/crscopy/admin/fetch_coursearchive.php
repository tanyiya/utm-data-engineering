<?php
include('../db-connect.php');

if (!isset($_GET['semester'])) {
    echo json_encode(['error' => 'Invalid semester.']);
    exit;
}

$semester = $_GET['semester'];

$coursequery = "SELECT * FROM tb_offeredcourse o
                LEFT JOIN tb_course c ON o.c_code = c.c_code
                LEFT JOIN tb_lecturer l ON o.c_lec = l.l_no
                LEFT JOIN tb_sem s ON o.c_sem = s.sem_id
                LEFT JOIN tb_coursestatus cs ON o.c_status = cs.status_id

                WHERE o.c_sem = ?";


$stmt = $con->prepare($coursequery);
$stmt->bind_param("i", $semester); 
$stmt->execute();
$result = $stmt->get_result();

$courses = [];
while ($row = $result->fetch_assoc()) {
    $courses[] = [
        'code' => $row['c_code'],
        'name' => $row['c_name'],
        'description' => $row['c_description'],
        'credits' => $row['c_credit'],
        'section' => $row['c_section'],
        'lecturer' => $row['l_name'],
        'max' => $row['c_maxstudent'],
        'stdqty' => $row['c_stdQuantity'],
        'tid' => $row['c_id'],
    ];
}



// Close connection
$con->close();

// Return the courses as JSON
echo json_encode($courses);
?>
