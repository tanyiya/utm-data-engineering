<?php
include('../db-connect.php');

error_reporting(0);
ini_set('display_errors', 0);

if ($con) {
    include 'courseamendment.php';
} else {
    echo "Failed to connect to the database.";
}

if (isset($_POST['student_id']) && isset($_POST['course_code']) && isset($_POST['new_section'])) {
    $student_id = mysqli_real_escape_string($con, $_POST['student_id']);
    $course_code = mysqli_real_escape_string($con, $_POST['course_code']);
    $new_section = mysqli_real_escape_string($con, $_POST['new_section']);

    // Update query to modify the course section for the student
    $query = "
        UPDATE tb_registration
        SET r_section = '{$new_section}'
        WHERE r_student = '{$student_id}' AND r_course = '{$course_code}'
    ";

    if (mysqli_query($con, $query)) {
        echo "success";
    } else {
        echo "error";
    }
} else {
    echo "error";
}
?>
