document.addEventListener('DOMContentLoaded', () => {
    const courseList = document.getElementById('course-list');
    const courseDetailsSection = document.getElementById('course-details-section');
    const semesterSelect = document.getElementById('semester-select');

    // Logout button functionality
    document.getElementById('logout-btn').addEventListener('click', function (event) {
        event.preventDefault();
        Swal.fire({
            title: 'Are you sure?',
            text: "Do you want to log out?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, log out!'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = '../logout.php';
            }
        });
    });

    // Fetch courses when semester changes
    semesterSelect.addEventListener('change', (e) => {
        fetchCourses(e.target.value);
    });

    // Fetch courses for the initially selected semester
    if (semesterSelect.value) {
        fetchCourses(semesterSelect.value);
    }

    // Fetch courses from the server
    async function fetchCourses(semester) {
        try {
            const response = await fetch(`fetch_coursearchive.php?semester=${semester}`);
            const courses = await response.json();

            if (courses.length === 0) {
                courseList.innerHTML = "<p>No courses found for the selected semester.</p>";
            } else {
                renderCourses(courses);
            }
        } catch (error) {
            console.error("Error fetching courses:", error);
        }
    }

    // Render the list of courses
    function renderCourses(courses) {
        courseList.innerHTML = courses.map(course => `
            <div class="course-item" 
                 data-code="${course.code}" 
                 data-name="${course.name}" 
                 data-description="${course.description}" 
                 data-credits="${course.credits}" 
                 data-section="${course.section}" 
                 data-lecturer="${course.lecturer}"
                 data-max="${course.max}"
                 data-stdqty="${course.stdqty}"
                 data-tid="${course.tid}">
                <h5><strong>${course.code}</strong></h5>
                <p><h5>${course.name}</h5></p>
                <p><strong>Section:</strong> ${course.section}</p>
            </div>
        `).join('');

        // Add event listeners to course items
        courseList.querySelectorAll('.course-item').forEach(item => {
            item.addEventListener('click', () => {
                renderCourseDetails({
                    code: item.dataset.code,
                    name: item.dataset.name,
                    description: item.dataset.description,
                    credits: item.dataset.credits,
                    section: item.dataset.section,
                    lecturer: item.dataset.lecturer,
                    max:item.dataset.max,
                    stdqty:item.dataset.stdqty,
                    tid:item.dataset.tid
                });
            });
        });
    }

    // Render course details and fetch student details
    function renderCourseDetails(course) {
        courseDetailsSection.innerHTML = `
            <div class="course-details">
                <div style="padding-right:15px" class="header-actions">
                    <button id="modify-btn" class="modify-btn">Modify</button>
                    <button id="delete-btn" class="delete-btn">Delete</button>
                </div>
                <h4>${course.code} - ${course.name}</h4>
                <p>${course.description}</p>
                <p><strong>Credits:</strong> ${course.credits}</p>
                <p><strong>Section:</strong> ${course.section}</p>
                <p><strong>Lecturer:</strong> ${course.lecturer}</p>
                <p><strong>Max Students:</strong> ${course.max}</p>
                <p><strong>Students Registered:</strong> ${course.stdqty}</p>
            </div>
            <h3>Student List</h3>
            <div id="student-list-container">
                <p>Loading students...</p>
            </div>
        `;

        fetchStudentDetails(course.code, course.section);

        // Attach event listeners to buttons
        document.getElementById('modify-btn').addEventListener('click', () => modifyCourse(course));
        document.getElementById('delete-btn').addEventListener('click', () => deleteCourse(course));
    }

    // Modify Course Function
    function modifyCourse(course) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'modifycoursesection.php';

        // Create hidden inputs for course details
        Object.keys(course).forEach(key => {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = key;
            input.value = course[key];
            form.appendChild(input);
        });

        document.body.appendChild(form);
        form.submit();
    }

    // Delete Course Function with Confirmation
    function deleteCourse(course) {
        Swal.fire({
            title: 'Are you sure?',
            text: "This will permanently delete the course.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = 'deleteprocess.php';

                // Create hidden inputs for course details
                Object.keys(course).forEach(key => {
                    const input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = key;
                    input.value = course[key];
                    form.appendChild(input);
                });

                document.body.appendChild(form);
                form.submit();
            }
        });
    }

    // Fetch student details for the selected course
    async function fetchStudentDetails(courseCode, courseSection) {
        try {
            const response = await fetch(`fetch_students.php?course_code=${courseCode}&course_section=${courseSection}`);
            const students = await response.json();

            if (students.length > 0) {
                renderStudentDetails(students);
            } else {
                document.getElementById('student-list-container').innerHTML = "<p>No students registered for this course.</p>";
            }
        } catch (error) {
            console.error("Error fetching student details:", error);
        }
    }

    // Render the student details in a table
    function renderStudentDetails(students) {
        const studentListContainer = document.getElementById('student-list-container');
        studentListContainer.innerHTML = `
            <table class="student-list">
                <thead>
                    <tr>
                        <th>Student Name</th>
                        <th>Student ID</th>
                        <th>Email</th>
                        <th>Contact Number</th>
                        <th>State</th>
                    </tr>
                </thead>
                <tbody>
                    ${students.map(student => `
                        <tr data-student-id="${student.id}">
                            <td>${student.name}</td>
                            <td>${student.student_no}</td>
                            <td>${student.email}</td>
                            <td>${student.contact}</td>
                            <td>${student.state}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    }
});
