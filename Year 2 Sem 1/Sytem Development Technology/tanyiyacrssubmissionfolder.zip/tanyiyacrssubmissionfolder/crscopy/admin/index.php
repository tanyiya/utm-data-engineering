<?php
include('headeradmin.php');
include('../db-connect.php');

// Fetch statistics
$totalCourses = $con->query("SELECT COUNT(*) as count FROM tb_course")->fetch_assoc()['count'];
$totalStudents = $con->query("SELECT COUNT(*) as count FROM tb_student")->fetch_assoc()['count'];
$totalLecturers = $con->query("SELECT COUNT(*) as count FROM tb_lecturer")->fetch_assoc()['count'];
$totalAdmins = $con->query("SELECT COUNT(*) as count FROM tb_admin")->fetch_assoc()['count'];
$con->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
    <style>
        .custom-btn {
            background-color: #bbdbf3; /* Light Blue */
            color: #000; /* Black Text */
            padding: 1.5rem;
            border-radius: 0.5rem;
            text-align: center;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s ease;
            display: block;
        }
        .custom-btn:hover {
            background-color: #a2c6e0; /* Slightly Darker Blue */
            transform: scale(1.05);
        }
    </style>
</head>

<body class="min-h-screen bg-gray-100">
    <div class="container mx-auto p-6">
        <!-- Dashboard Overview -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="bg-white p-6 rounded-lg shadow-md flex items-center space-x-4">
                <div class="text-blue-500 text-3xl">📊</div>
                <div>
                    <p class="text-xl font-semibold"><?php echo $totalCourses; ?></p>
                    <p class="text-gray-500">Total Courses</p>
                </div>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-md flex items-center space-x-4">
                <div class="text-green-500 text-3xl">👥</div>
                <div>
                    <p class="text-xl font-semibold"><?php echo $totalStudents; ?></p>
                    <p class="text-gray-500">Total Students</p>
                </div>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-md flex items-center space-x-4">
                <div class="text-purple-500 text-3xl">📚</div>
                <div>
                    <p class="text-xl font-semibold"><?php echo $totalLecturers; ?></p>
                    <p class="text-gray-500">Total Lecturers</p>
                </div>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-md flex items-center space-x-4">
                <div class="text-yellow-500 text-3xl">🛠️</div>
                <div>
                    <p class="text-xl font-semibold"><?php echo $totalAdmins; ?></p>
                    <p class="text-gray-500">Admins</p>
                </div>
            </div>
        </div>

        <!-- Functionalities Section -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <a href="coursearchive.php" class="custom-btn">📂 View Courses</a>
            <a href="addcourse.php" class="custom-btn">➕ Add Course</a>
            <a href="addsection.php" class="custom-btn">➕ Add Section</a>
            <a href="courseamendment.php" class="custom-btn">🔄 Registration Amendment</a>
        </div>
    </div>
<script src="app.js"></script>

</body>
</html>
