<?php
include('headeradmin.php');
include('../db-connect.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Search</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <div class="student-search-container">
        <h2>Search for Student</h2>
        
        <div class="search-section">
            <input 
                type="text" 
                id="student-search" 
                placeholder="Search by name or student ID" 
                class="search-input"
                autocomplete="off"
            >
            <button id="search-btn" class="search-btn">Search</button>
        </div>

        <div id="student-results" class="student-results">
            <!-- Search results will be dynamically populated here -->
        </div>

        <div id="student-details" class="student-details">
            <!-- Student details will be dynamically populated here -->
        </div>
    </div>

 <script type="text/javascript">
   $(document).ready(function () {
    $("#student-search").keyup(function () {
        var input = $(this).val().trim();

        if (input !== "") {
            $.ajax({
                url: "search.php",
                method: "POST",
                data: { input: input },
                success: function (response) {
                    $("#student-results").html(response);
                },
                error: function () {
                    $("#student-results").html("<h6 class='text-danger text-center mt-3'>Error loading students</h6>");
                }
            });
        } else {
            $("#student-results").html(data).show();
        }
    });

    // Handle click on student row
    $(document).on("click", ".student-row", function () {
        var student_id = $(this).data("id");

        $.ajax({
            url: "get-registeredcourse.php",
            method: "POST",
            data: { student_id: student_id },
            success: function (response) {
                try {
                    const student = JSON.parse(response);

                    if (student.error) {
                        $("#student-details").html(`<h6 class='text-danger text-center mt-3'>${student.error}</h6>`);
                    } else {
                        displayStudentDetails(student.student);
                    }
                } catch (e) {
                    $("#student-details").html("<h6 class='text-danger text-center mt-3'>Unable to load student details</h6>");
                }
            },
            error: function () {
                $("#student-results").hide();
            }
        });
    });
});

function displayStudentDetails(student) {
    let courseRows = student.courses.length > 0
        ? student.courses.map(course => `
            <tr>
                <td>${course.course_code}</td>
                <td>${course.section}</td>
                <td>${course.semester}</td>
                <td>${course.status}</td>
                <td>
                    <button class="logout-btn" 
                        onclick="amendCourse('${student.id}', '${course.course_code}', '${course.section}')">
                        Amend
                    </button>
                </td>
            </tr>
        `).join('')
        : `<tr><td colspan="5" class="text-center">No registered courses</td></tr>`;

    let html = `
        <h3>${student.id} - ${student.name}</h3>
        <p><strong>Contact:</strong> ${student.contact}</p>
        <p><strong>State:</strong> ${student.state}</p>
        
        <h4>Registered Courses</h4>
        <table class="table table-borderless">
            <thead>
                <tr>
                    <th>Course Code</th>
                    <th>Section</th>
                    <th>Semester</th>
                    <th>Status</th>
                    <th>Action</th> <!-- New Column for the "Amend" Button -->
                </tr>
            </thead>
            <tbody>
                ${courseRows}
            </tbody>
        </table>
    `;

    $("#student-details").html(html);
}

function amendCourse(studentId, courseCode, currentSection) {
    Swal.fire({
        title: 'Enter New Section',
        input: 'text',
        inputLabel: 'New Section',
        inputPlaceholder: 'eg, 1, 2',
        showCancelButton: true,
        confirmButtonText: 'Update Section',
        cancelButtonText: 'Cancel',
        preConfirm: (newSection) => {
            if (!newSection) {
                Swal.showValidationMessage('Please enter a section');
            } else {
                return newSection;
            }
        }
    }).then((result) => {
        if (result.isConfirmed) {
            let newSection = result.value.trim();

            // Send the updated section to the PHP server for processing
            $.ajax({
                url: 'update_section.php',  // PHP file to update section
                method: 'POST',
                data: {
                    student_id: studentId,
                    course_code: courseCode,
                    new_section: newSection
                },
                success: function(response) {
                    if (response.trim() === "success") {
                        Swal.fire('Success', 'Section updated successfully', 'success');
                        // Refresh the student details to reflect the new section
                        location.reload();
                    } else if (response.trim() === "error"){
                        Swal.fire('Error', 'Failed to update section', 'error');
                    } else{
                        Swal.fire('Sucess', 'Section updated successfully', 'success');
                        location.reload();
                        //random error check again
                    }
                },
                error: function() {
                    Swal.fire('Error', 'An error occurred while updating the section', 'error');
                }
            });
        }
    });
}





 </script>
    <script src="app.js"></script>

</body>
</html>
