<?php
include('headeradmin.php');
include('../login/loginfunction.php');
include('../db-connect.php');
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cleanPost = cleanPost($_POST);
    $c_code = mysqli_real_escape_string($con, $cleanPost['course_code']);
    $c_lec = mysqli_real_escape_string($con, $cleanPost['lecturer']);
    $c_sem = mysqli_real_escape_string($con, $_SESSION['current_sem']);
    $c_section = mysqli_real_escape_string($con, $cleanPost['section']);
    $c_maxstudent = mysqli_real_escape_string($con, $cleanPost['max_students']);

    $check_query = "SELECT * FROM tb_offeredcourse WHERE c_code = '$c_code' AND c_section = '$c_section' AND c_sem = '$c_sem'";
    $check_result = mysqli_query($con, $check_query);

    if (mysqli_num_rows($check_result) > 0) {
        echo "
            <script>
                Swal.fire({
                    title: 'Error!',
                    text: 'The section for this course already exists!',
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
            </script>
        ";
    } else {
 
        $insert_query = "INSERT INTO tb_offeredcourse (c_code, c_lec, c_sem, c_section, c_status, c_maxstudent)
                         VALUES ('$c_code', '$c_lec', '$c_sem', '$c_section', '1', '$c_maxstudent')";


        if (mysqli_query($con, $insert_query)) {
            echo "
                <script>
                    Swal.fire({
                        title: 'Success!',
                        text: 'Course successfully added!',
                        icon: 'success',
                        confirmButtonText: 'OK'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = 'addsection.php'; // Redirect to the add section page
                        }
                    });
                </script>
            ";
        } else {
            echo "
                <script>
                    Swal.fire({
                        title: 'Error!',
                        text: 'Error: " . mysqli_error($con) . "',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                </script>
            ";
        }
    }
}

?>
<div style="overflow-y: auto; height: 90vh;">
<div class="add-course-container">
        <h2>Add Course Section</h2>
        <form id="add-course-form" method="POST" action="addsection.php">
            <div class="form-group">
            <label for="lecturer-select">Select Course</label>
                <select id="lecturer-select" name="course_code" required>
                    <option value="" disabled selected>Select Course</option>
                    <?php
                    $course_query = "SELECT * FROM tb_course";
                    $course_result = mysqli_query($con, $course_query);
                    while ($courses = mysqli_fetch_assoc($course_result)) {
                        echo "<option value='{$courses['c_code']}'>{$courses['c_code']}-{$courses['c_name']}</option>";
                    }
                    ?>
                </select>
            </div>
            
            <div class="form-group">
                <label for="lecturer-select">Select Lecturer</label>
                <select id="lecturer-select" name="lecturer" required>
                    <option value="" disabled selected>Select Lecturer</option>
                    <?php
                    $lecturer_query = "SELECT * FROM tb_lecturer";
                    $lecturer_result = mysqli_query($con, $lecturer_query);
                    while ($lecturer = mysqli_fetch_assoc($lecturer_result)) {
                        echo "<option value='{$lecturer['l_no']}'>{$lecturer['l_name']}</option>";
                    }
                    ?>
                </select>
            </div>

            
            <div class="form-group">
                <label for="section">Section</label>
                <input type="number" id="section" name="section" placeholder="Enter section" required>
            </div>
            
            <div class="form-group">
                <label for="max-students">Maximum Students per Section</label>
                <input type="number" id="max-students" name="max_students" min=10" placeholder="Enter maximum number of students" required>
            </div>
            
            <button type="submit" class="add-course-btn">Open Course</button>
        </form>
    </div>
</div>

<script src="app.js"></script>
