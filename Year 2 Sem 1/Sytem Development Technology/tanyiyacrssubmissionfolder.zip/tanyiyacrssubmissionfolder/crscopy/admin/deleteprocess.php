<?php
include('../login/loginfunction.php');
include('../db-connect.php');
session_start();

if ($con) {
    include 'coursearchive.php';
} else {
    echo "Failed to connect to the database.";
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $c_tid = $_POST['tid'] ?? '';
    $c_section = $_POST['section'] ?? '';
    $c_sem = $_SESSION['current_sem'] ?? '';
    $c_course = $_POST['course'] ?? '';

    // Check if tid is provided
    if (empty($c_tid)) {
        echo "<script>
                Swal.fire({
                    title: 'Error!',
                    text: 'No course section selected for deletion!',
                    icon: 'error',
                    confirmButtonText: 'OK'
                }).then(() => { window.location.href = 'coursearchive.php'; });
              </script>";
        exit;
    }

    // Delete the course section from tb_offeredcourse based on c_tid
    $delete_course_query = "DELETE FROM tb_offeredcourse WHERE c_id = '$c_tid'";

    // Delete related rows in tb_registration based on r_course, r_section, r_sem
    $delete_registration_query = "DELETE FROM tb_registration WHERE r_course = '$c_course' AND r_section = '$c_section' AND r_sem = '$c_sem'";

    // Begin transaction to ensure both deletions are handled together
    mysqli_begin_transaction($con);

    try {
        // Execute the delete queries
        if (mysqli_query($con, $delete_course_query) && mysqli_query($con, $delete_registration_query)) {
            // Commit transaction if both delete queries succeed
            mysqli_commit($con);

            echo "<script>
                    Swal.fire({
                        title: 'Success!',
                        text: 'Course section and related registrations deleted successfully!',
                        icon: 'success',
                        confirmButtonText: 'OK'
                    }).then(() => { window.location.href = 'coursearchive.php'; });
                  </script>";
        } else {
            // Rollback transaction if any query fails
            mysqli_rollback($con);
            echo "<script>
                    Swal.fire({
                        title: 'Error!',
                        text: 'Error: " . mysqli_error($con) . "',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                  </script>";
        }
    } catch (Exception $e) {
        // Rollback in case of exception
        mysqli_rollback($con);
        echo "<script>
                Swal.fire({
                    title: 'Error!',
                    text: 'Exception occurred: " . $e->getMessage() . "',
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
              </script>";
    }
} else {
    // If no POST request, redirect to the course archive page
    header('Location: coursearchive.php');
    exit;
}
?>
