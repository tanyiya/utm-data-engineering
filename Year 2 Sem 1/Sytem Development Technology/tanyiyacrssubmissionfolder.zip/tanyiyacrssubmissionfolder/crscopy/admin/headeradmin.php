<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Registration System - Lecturer</title>
    <link rel="icon" type="image/x-icon" href="../img/kuromi.ico">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>

<?
include('../loginfunction.php');
include('../crs_session.php');
if(!session_id())
{
  session_start();
}
if ($_SESSION['u_utype'] != 3) {
  header('Location: ../login');
  exit();
}

if (!isset($_SESSION['u_sno'])) {
    header('Location: ../login');
    exit();
}
?>

<div class="admin-dashboard">
    <header class="admin-header" style="position: sticky">
            <h1 style="margin: 0; padding-left: 15px">Admin Management Portal</h1>
            <div class="header-actions" style="padding-right:15px">
                <a href="index.php" class="link">Dashboard</a>
                <a href="coursearchive.php" class="link">Courses</a>
                <div class="dropdown">
                    <button class="dropbtn">Functions &#x25BC
                        <i class="fa fa-caret-down"></i>
                    </button>
                    <div class="dropdown-content">
                        <a href="addsection.php">Add section</a>
                        <a href="addcourse.php">Add course</a>
                        <a href="courseamendment.php">Registration Amendment</a>
                    </div>
                </div>
                <button id="logout-btn" class="logout-btn">Logout</button>
            </div>
    </header>
