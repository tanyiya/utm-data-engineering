<?php
include('../db-connect.php');

if (isset($_POST['student_id'])) {
    $student_id = mysqli_real_escape_string($con, $_POST['student_id']);

    $query = "
        SELECT 
            s.s_no, s.s_name, s.s_contact, s.s_state, 
            r.r_course, r.r_section, r.r_sem, 
            st.status_desc, sem.semester
        FROM tb_student s
        LEFT JOIN tb_registration r ON s.s_no = r.r_student
        LEFT JOIN tb_regstatus st ON r.r_status = st.status_id
        LEFT JOIN tb_sem sem ON r.r_sem = sem.sem_id
        WHERE s.s_no = '{$student_id}'
    ";

    $result = mysqli_query($con, $query);
    $student_data = [];

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            if (!isset($student_data['student'])) {
                $student_data['student'] = [
                    'id' => $row['s_no'],
                    'name' => $row['s_name'],
                    'contact' => $row['s_contact'],
                    'state' => $row['s_state'],
                    'courses' => []
                ];
            }

            if ($row['r_course']) {
                $student_data['student']['courses'][] = [
                    'course_code' => $row['r_course'],
                    'section' => $row['r_section'],
                    'semester' => $row['semester'], 
                    'status' => $row['status_desc']
                ];
            }
        }
        echo json_encode($student_data);
    } else {
        echo json_encode(["error" => "Student details not found"]);
    }
}
?>
