<?php
include('../db-connect.php');


$courseCode = $_GET['course_code'];
$courseSection = $_GET['course_section'];

// SQL query
$sql = "
    SELECT 
        s.s_no AS student_no,
        s.s_name AS name,
        s.s_contact AS contact,
        u.u_email AS email,
        s.s_state AS state
    FROM 
        tb_registration r
    JOIN 
        tb_student s ON r.r_student = s.s_no
    JOIN 
        tb_user u ON s.s_no = u.u_sno
    WHERE 
        r.r_course = ? AND
        r.r_section = ?;
    ";

    $stmt = $con->prepare($sql);
    $stmt->bind_param('si', $courseCode, $courseSection);
    $stmt->execute();
    $result = $stmt->get_result();

    $students = [];
    while ($row = $result->fetch_assoc()) {
        $students[] = $row;
    }

    echo json_encode($students);


?>
