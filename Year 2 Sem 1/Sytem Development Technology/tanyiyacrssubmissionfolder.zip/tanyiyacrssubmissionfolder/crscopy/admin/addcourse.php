<?php
include('headeradmin.php');
include('../login/loginfunction.php');
include('../db-connect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cleanPost = cleanPost($_POST);
    $code = mysqli_real_escape_string($con, $cleanPost['code']);
    $name = mysqli_real_escape_string($con, $cleanPost['name']);
    $credit = mysqli_real_escape_string($con, $cleanPost['credit']);
    $type = mysqli_real_escape_string($con, $cleanPost['type']);
    $description = mysqli_real_escape_string($con, $cleanPost['description']);

    $check_query = "SELECT * FROM tb_course WHERE c_code = '$code'";
    $check_result = mysqli_query($con, $check_query);

    if (mysqli_num_rows($check_result) > 0) {
        echo "
            <script>
                Swal.fire({
                    title: 'Error!',
                    text: 'This course already exists!',
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
            </script>
        ";
    } else {
 
        $insert_query = "INSERT INTO tb_course (c_code, c_name, c_credit, c_type, c_description)
                         VALUES ('$code', '$name', '$credit', '$type', '$description')";


        if (mysqli_query($con, $insert_query)) {
            echo "
                <script>
                    Swal.fire({
                        title: 'Success!',
                        text: 'Course successfully added!',
                        icon: 'success',
                        confirmButtonText: 'OK'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = 'addcourse.php'; // Redirect to the add section page
                        }
                    });
                </script>
            ";
        } else {
            echo "
                <script>
                    Swal.fire({
                        title: 'Error!',
                        text: 'Error: " . mysqli_error($con) . "',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                </script>
            ";
        }
    }
}

?>
<div style="overflow-y: auto; height: 90vh;">
<div class="add-course-container">
        <h2>Add Course</h2>
        <form id="add-course-form" method="POST" action="addcourse.php">
            <div class="form-group">
            <label for="code">Course Code</label>
            <input type="text" id="code" name="code" placeholder="Enter course code" required>
            </div>
            
            <div class="form-group">
            <label for="name">Course Name</label>
            <input type="text" id="name" name="name" placeholder="Enter course name" required>
            </div>

            <div class="form-group">
            <label for="credit">Course Credit</label>
            <input type="number" id="credit" name="credit" placeholder="Enter credit" required>
            </div>

            <div class="form-group">
            <label for="type">Course Type</label>
            <select id="type" name="type" required>
                    <option value="" disabled selected>Select course type</option>
                    <?php
                    $query = "SELECT * FROM tb_coursetype";
                    $result = mysqli_query($con, $query);
                    while ($type = mysqli_fetch_assoc($result)) {
                        echo "<option value='{$type['type_id']}'>{$type['type_desc']}</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
            <label for="description">Course Description</label>
            <textarea id="description" name="description" rows="6" placeholder="Enter description" required></textarea>
            </div>
            
            <button type="submit" class="add-course-btn">Add Course</button>
        </form>
    </div>
</div>

<script src="app.js"></script>
