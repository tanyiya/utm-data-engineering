<?php
include('../db-connect.php');

if (isset($_POST['input'])) {
    $input = $_POST['input'];

    // Query to fetch courses matching the input
    $query = "
        SELECT 
            c.c_code, c.c_name, c.c_credit, o.c_section 
        FROM tb_course c
        JOIN tb_offeredcourse o ON c.c_code = o.c_code
        WHERE o.c_code LIKE '{$input}%'
        OR c.c_name LIKE '{$input}%'
        AND o.c_status = 1"; // Assuming 1 means 'open'

    $result = mysqli_query($con, $query);

    $courses = [];
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $courses[$row['c_code']]['code'] = $row['c_code'];
            $courses[$row['c_code']]['name'] = $row['c_name'];
            $courses[$row['c_code']]['credits'] = $row['c_credit'];
            $courses[$row['c_code']]['sections'][] = $row['c_section'];
        }
        // Return JSON response
        echo json_encode(array_values($courses));
    } else {
        // No data found
        echo json_encode(["error" => "No data found"]);
    }
}
?>
