<?php
include ('../db-connect.php');
session_start();

// Query to get the courses along with their details
$sql = "
    SELECT 
        c.c_code, c.c_name, c.c_credit, c.c_description,
        o.c_sem, o.c_section
    FROM tb_course c
    JOIN tb_offeredcourse o ON c.c_code = o.c_code
    WHERE o.c_status = 1 AND o.c_sem = {$_SESSION['current_sem']}";  // Assuming 1 is 'open' status for offered courses
$result = $con->query($sql);

$courses = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Group sections for each course
        $courses[$row['c_code']]['code'] = $row['c_code'];
        $courses[$row['c_code']]['name'] = $row['c_name'];
        $courses[$row['c_code']]['credits'] = $row['c_credit'];
        $courses[$row['c_code']]['sections'][] = $row['c_section'];
    }
} else {
    echo json_encode(["error" => "No courses found"]);
    exit;
}

// Close connection
$con->close();

// Return the courses as JSON
echo json_encode(array_values($courses));
?>
