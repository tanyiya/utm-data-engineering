<?php   
include('headerstu.php');
include('../db-connect.php');

include('../crs_session.php');
if(!session_id())
{
  session_start();
}
if ($_SESSION['u_utype'] != 2) {
  header('Location: ../login');
  exit();
}

if (!isset($_SESSION['u_sno'])) {
    header('Location: ../login');
    exit();
}

if(isset($_SESSION['u_sno'])) {
    $profilequery = "SELECT * FROM tb_student WHERE s_no = '{$_SESSION['u_sno']}'";
    $profile_result = mysqli_query($con, $profilequery);
    $student = mysqli_fetch_assoc($profile_result);
    //var_dump($student);
    $emailquery = "SELECT u_email FROM tb_user WHERE u_sno = '{$_SESSION['u_sno']}'";
    $email_result = mysqli_query($con, $emailquery);
    $email = mysqli_fetch_assoc($email_result);
    //var_dump($email);
}
?>

        <main class="registration-main">
            <section class="course-list-section">
                <div class="search-container">
                    <input type="text" id="course-search" placeholder="Search courses by name, code, or department..." autocomplete="off">
                </div>
                <div class="course-list" id="course-list">
                    <!-- Course items will be dynamically populated here -->
                </div>
                <div class="search-list" id="search-results">
                    <!-- Search results will appear here -->
                </div>
            </section>

            <aside class="registered-courses-section">
                <h2>Register Courses</h2>
                <h6>Note: You must make sure all courses are selected, and selected correctly before submitting.</h6>
                <div id="registered-courses-list" class="registered-courses-list">
                    <!-- Registered courses will be dynamically added here -->

                </div>
                <button id="submit-registration" class="submit-btn">Submit Registration</button>
            </aside>
        </main>
    </div>


    <!-- Profile Modal -->
<div id="profile-modal" class="modal">
        <div class="modal-content">
        <div class="modal-header">
        <span class="close-modal">&times;</span>
        <h2>Student Profile</h2>
        </div>
            <form id="profile-form" method="POST" action="update_profile.php"> 
                <div class="form-group">
                    <label for="full-name">Full Name</label>
                    <input type="text" id="full-name" name="fname" value="<?php echo $student['s_name']; ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="staff-number">Staff Number</label>
                    <input type="text" id="fno" name="fno" value="<?php echo $student['s_no']; ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="femail">Email</label>
                    <input type="email" id="femail" name="femail" value="<?php echo $email['u_email']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="fcontact">Contact Number</label>
                    <input type="tel" id="fcontact" name="fcontact" value="<?php echo $student['s_contact']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="fstate">State</label>
                    <input type="text" id="fstate" name="fstate" value="<?php echo $student['s_state']; ?>" required>
                </div>
                <button type="submit" class="save-profile-btn">Update Profile</button>
            </form>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', () => {
        const courseList = document.getElementById('course-list');
        const registeredCoursesList = document.getElementById('registered-courses-list');
        const courseSearch = document.getElementById('course-search');
        const submitRegistrationBtn = document.getElementById('submit-registration');

        // Profile Modal Functionality
        const profileBtn = document.getElementById('profile-btn');
    const profileModal = document.getElementById('profile-modal');
    const closeProfileModal = profileModal.querySelector('.close-modal');
    const profileForm = document.getElementById('profile-form');

    profileBtn.addEventListener('click', () => {
        profileModal.style.display = 'block';
    });

    closeProfileModal.addEventListener('click', () => {
        profileModal.style.display = 'none';
    });

        
        document.getElementById('logout-btn').addEventListener('click', function(event) {
            event.preventDefault();
            Swal.fire({
                title: 'Are you sure?',
                text: "Do you want to log out?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, log out!'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '../logout.php';
                }
            });
        });
    

        
        $(document).ready(function () {
            $("#course-search").keyup(function () {
                var input = $(this).val();

                if (input != "") {
                    $("#course-list").css("display", "none");
                    
                    $.ajax({
                        url: "livesearch.php",
                        method: "POST",
                        data: { input: input },
                        success: function (response) {
                            try {
                                const courses = JSON.parse(response);

                                if (courses.error) {
                                    $("#search-results").html(`<h6 class='text-danger text-center mt-3'>${courses.error}</h6>`);
                                } else {
                                    searchCourses(courses);
                                }

                                $("#search-results").css("display", "block");

                            } catch (e) {
                                $("#search-results").html("<h6 class='text-danger text-center mt-3'>Unable to load courses. Please try again later.</h6>");
                                $("#search-results").css("display", "block");
                            }
                        },
                        error: function () {
                            $("#search-results").html("<h6 class='text-danger text-center mt-3'>Error loading courses</h6>");
                            $("#search-results").css("display", "block");
                        }
                    });
                } else {
                    $("#search-results").css("display", "none");
                    $("#course-list").css("display", "block");
                }
            });
        });

 // Function to render the search courses
function searchCourses(courses) {
    let html = courses.map(course => `
        <div class="course-item mt-3">
            <div class="course-details">
                <h3>${course.code} - ${course.name}</h3>
                <p>Credits: ${course.credits}</p>
            </div>
            <div class="course-actions">
                <select class="section-dropdown">
                    <option value="">Select Section</option>
                    ${course.sections.map(section => `
                        <option value="${section}">${section}</option>
                    `).join('')}
                </select>
                <button class="register-btn" data-code="${course.code}">Register</button>
            </div>
        </div>
    `).join(''); 

    $("#search-results").html(html);

    // Add event listeners for registration
    document.querySelectorAll('.register-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const courseCode = e.target.dataset.code;
            const sectionDropdown = e.target.previousElementSibling;
            const selectedSection = sectionDropdown.value;

            if (selectedSection) {
                const course = courses.find(c => c.code === courseCode);
                addRegisteredCourse(course, selectedSection);
            } else {
                Swal.fire({
                    icon: 'warning',
                    title: 'Oops...',
                    text: 'Please select a section',
                });
            }
        });
    });
}

        // Fetch courses from the backend dynamically
        async function fetchCourses() {
            try {
                const response = await fetch('fetch_courses.php'); 
                const courses = await response.json();

                if (courses.error) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: courses.error,
                    });
                    return;
                }

                renderCourses(courses);
            } catch (error) {
                console.error("Error fetching courses:", error);
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Error fetching courses',
                });
            }
        }

        // Render courses
        function renderCourses(courses) {
            courseList.innerHTML = courses.map(course => `
                <div class="course-item">
                    <div class="course-details">
                        <h3>${course.code} - ${course.name}</h3>
                        <p>Credits: ${course.credits}</p>
                    </div>
                    <div class="course-actions">
                        <select class="section-dropdown">
                            <option value="">Select Section</option>
                            ${course.sections.map(section => `
                                <option value="${section}">Section ${section}</option>
                            `).join('')}
                        </select>
                        <button class="register-btn" data-code="${course.code}">Register</button>
                    </div>
                </div>
            `).join('');

            // Add event listeners for registration
            document.querySelectorAll('.register-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const courseCode = e.target.dataset.code;
                    const sectionDropdown = e.target.previousElementSibling;
                    const selectedSection = sectionDropdown.value;

                    if (selectedSection) {
                        const course = courses.find(c => c.code === courseCode);
                        addRegisteredCourse(course, selectedSection);
                    } else {
                        Swal.fire({
                            icon: 'warning',
                            title: 'Oops...',
                            text: 'Please select a section',
                        });
                    }
                });
            });
        }

        // Add registered course
        function addRegisteredCourse(course, section) {
            const registeredCourseItem = document.createElement('div');
            registeredCourseItem.classList.add('registered-course-item');
            registeredCourseItem.innerHTML = `
                <div>
                    <strong>${course.code}</strong> - ${course.name}
                    <br>
                    <small>Section ${section}</small>
                </div>
                <button class="remove-course-btn">✕</button>
            `;

            // Remove course functionality
            registeredCourseItem.querySelector('.remove-course-btn').addEventListener('click', () => {
                registeredCourseItem.remove();
            });

            registeredCoursesList.appendChild(registeredCourseItem);
        }

        // Initial course rendering
        fetchCourses();

        submitRegistrationBtn.addEventListener('click', () => {
    const registeredCourses = Array.from(registeredCoursesList.children).map(item => {
        const details = item.querySelector('div');
        return {
            code: details.querySelector('strong').textContent,
            section: details.querySelector('small').textContent.replace('Section', '').trim()
        };
    });

    if (registeredCourses.length > 0) {
        Swal.fire({
            title: 'Confirm Registration',
            text: "Are you sure you want to submit your course registration? This action cannot be undone.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, Submit!',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'registercourse.php',
                    method: 'POST',
                    data: {
                        registeredCourses: JSON.stringify(registeredCourses),
                        semester: 3 // Hardcoded semester ID for now
                    },
                    success: function (response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Registration Successful',
                            text: response,
                        });
                    },
                    error: function () {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Error saving registration data.',
                        });
                    }
                });
            }
        });
    } else {
        Swal.fire({
            icon: 'warning',
            title: 'Oops...',
            text: 'Please select courses before submitting.',
        });
    }
});

});

</script>
</body>
</html>
