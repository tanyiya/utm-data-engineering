<?php   
include('headerstu2.php');
include('../db-connect.php');
include('../crs_session.php');

if (!session_id()) {
    session_start();
}

if ($_SESSION['u_utype'] != 2) {
    header('Location: ../login');
    exit();
}

if (!isset($_SESSION['u_sno'])) {
    header('Location: ../login');
    exit();
}

if (isset($_SESSION['u_sno'])) {
    $regcoursequery = "SELECT * FROM tb_registration r 
                       LEFT JOIN tb_course c ON r.r_course = c.c_code
                       LEFT JOIN tb_offeredcourse o ON r.r_course = o.c_code AND r.r_section = o.c_section
                       LEFT JOIN tb_lecturer l ON o.c_lec = l.l_no
                       WHERE r_student = '{$_SESSION['u_sno']}' 
                       AND r_sem = {$_SESSION['current_sem']}";

    $regcoursequery_result = mysqli_query($con, $regcoursequery);
    $regcourses = [];
    while ($row = mysqli_fetch_assoc($regcoursequery_result)) {
        $regcourses[] = $row;
    }

    $profilequery = "SELECT * FROM tb_student WHERE s_no = '{$_SESSION['u_sno']}'";
    $profile_result = mysqli_query($con, $profilequery);
    $student = mysqli_fetch_assoc($profile_result);

    $emailquery = "SELECT u_email FROM tb_user WHERE u_sno = '{$_SESSION['u_sno']}'";
    $email_result = mysqli_query($con, $emailquery);
    $email = mysqli_fetch_assoc($email_result);
}
?>

<style>
.dashnoad-main {
    display: flex;
    gap: 20px;
    align-items: flex-start;
}

.courses-list-section {
    width: 30%;
    background-color: var(--color-new);
    padding: 20px;
    overflow-y: auto;
    height: 90vh
}

.course-details-section {
    width: 70%;
    background-color: var(--color-white);
    padding: 20px;
    overflow-y: auto;
}

@media (max-width: 768px) { 
    .dashnoad-main {
        flex-direction: column;
    }

    .courses-list-section, 
    .course-details-section {
        width: 100%;
    }
}

.course-list {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.course-item {
    background-color: var(--color-light);
    padding: 15px;
    border-radius: var(--border-radius);
    cursor: pointer;
    transition: all var(--transition-speed);
    border: 1px solid var(--color-primary);
}

.course-item:hover {
    background-color: var(--color-primary);
    color: var(--color-white);
}

.course-details {
    background-color: var(--color-white);
    padding: 20px;
    margin-bottom: 20px;
}


</style>

<div class="dashnoad-main">
    <div class="courses-list-section">
        <h2>Registered Courses</h2>
        <br>
        <div class="course-list">
            <?php if (!empty($regcourses)): ?>
                <?php foreach ($regcourses as $course): ?>
                    <div class="course-item" data-course='<?php echo json_encode($course); ?>'>
                        <h4><?php echo htmlspecialchars($course['r_course']); ?> - <?php echo htmlspecialchars($course['c_name']); ?></h4>
                        <p><strong>Section:</strong> <?php echo htmlspecialchars($course['r_section']); ?></p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No courses registered yet.</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="course-details-section">
        <h2>Course Details</h2>
        <div class="course-details">
            <p>Select a course to see details here.</p>
        </div>
    </div>
</div>

<!-- Profile Modal -->
<div id="profile-modal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <span class="close-modal">&times;</span>
            <h2>Student Profile</h2>
        </div>
        <form id="profile-form" method="POST" action="update_profile.php"> 
            <div class="form-group">
                <label for="full-name">Full Name</label>
                <input type="text" id="full-name" name="fname" value="<?php echo htmlspecialchars($student['s_name']); ?>" readonly>
            </div>
            <div class="form-group">
                <label for="staff-number">Staff Number</label>
                <input type="text" id="fno" name="fno" value="<?php echo htmlspecialchars($student['s_no']); ?>" readonly>
            </div>
            <div class="form-group">
                <label for="femail">Email</label>
                <input type="email" id="femail" name="femail" value="<?php echo htmlspecialchars($email['u_email']); ?>" required>
            </div>
            <div class="form-group">
                <label for="fcontact">Contact Number</label>
                <input type="tel" id="fcontact" name="fcontact" value="<?php echo htmlspecialchars($student['s_contact']); ?>" required>
            </div>
            <div class="form-group">
                <label for="fstate">State</label>
                <input type="text" id="fstate" name="fstate" value="<?php echo htmlspecialchars($student['s_state']); ?>" required>
            </div>
            <button type="submit" class="save-profile-btn">Update Profile</button>
        </form>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">
document.addEventListener('DOMContentLoaded', () => {
    
    // Course Click Event to Display Details
    document.querySelectorAll('.course-item').forEach(item => {
        item.addEventListener('click', function () {
            let courseData = JSON.parse(this.dataset.course);
            document.querySelector('.course-details').innerHTML = `
                <h3>${courseData.r_course} - ${courseData.c_name}</h3>
                <p><strong>Section:</strong> ${courseData.r_section}</p>
                <p><strong>Credits:</strong> ${courseData.c_credit || 'N/A'}</p>
                <p><strong>Lecturer:</strong> ${courseData.l_name || 'Not Assigned'}</p>
                <p><strong>Description:</strong> ${courseData.c_description || 'No description available.'}</p>
            `;
        });
    });

    // Profile Modal Functionality
    const profileBtn = document.getElementById('profile-btn');
    const profileModal = document.getElementById('profile-modal');
    const closeProfileModal = document.querySelector('.close-modal');

    if (profileBtn && profileModal) {
        profileBtn.addEventListener('click', () => {
            profileModal.style.display = 'block';
        });

        closeProfileModal.addEventListener('click', () => {
            profileModal.style.display = 'none';
        });
    }

    // Logout Confirmation
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(event) {
            event.preventDefault();
            Swal.fire({
                title: 'Are you sure?',
                text: "Do you want to log out?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, log out!'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '../logout.php';
                }
            });
        });
    }
});
</script>
</body>
</html>
