<?php
session_start();
include('../db-connect.php'); // Replace with your DB connection script

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $registeredCourses = json_decode($_POST['registeredCourses'], true);
    $semester = $_POST['semester'];
    $studentId = $_SESSION['u_sno'];
    $errors = [];
    $successCount = 0;

    foreach ($registeredCourses as $course) {
        $courseCode = $course['code'];
        $courseSection = $course['section'];

        // Check course availability
        $checkQuery = "SELECT c_stdQuantity, c_maxstudent FROM tb_offeredcourse WHERE c_code = ?";
        $stmt = $con->prepare($checkQuery);
        $stmt->bind_param('s', $courseCode);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $r_status = ($row['c_stdQuantity'] < $row['c_maxstudent']) ? 2 : 1;

            // Insert into tb_registration
            $insertQuery = "INSERT INTO tb_registration (r_student, r_course, r_section, r_sem, r_status)
                            VALUES (?, ?, ?, ?, ?)";
            $stmt = $con->prepare($insertQuery);
            $stmt->bind_param('ssiii', $studentId, $courseCode, $courseSection, $semester, $r_status);

            if ($stmt->execute()) {
                $successCount++;
            } else {
                $errors[] = "Failed to register for course $courseCode.";
            }
        } else {
            $errors[] = "Course $courseCode not found.";
        }
    }

    // Response
    if (count($errors) > 0) {
        echo "Registration completed with errors:\n" . implode("\n", $errors);
    } else {
        echo "$successCount courses registered successfully.";
    }
}
?>
