<?php
// Connect to DB
include('../db-connect.php');

if ($con) {
    include 'index.php';
} else {
    echo "Failed to connect to the database.";
}

function displayAlertAndRedirect1($type, $title, $message, $redirect = null) {
    echo "<script>
        Swal.fire({
            icon: '$type',
            title: '$title',
            text: '$message',
            confirmButtonText: 'OK'
        }).then(() => {";
    
    if ($redirect) {
        echo "window.location.href = '$redirect';";
    }

    echo "});
    </script>";
    exit;
}

if (!isset($_POST['femail'], $_POST['fcontact'], $_POST['fstate'], $_POST['fno'])) {
    displayAlertAndRedirect1("error", "Error", "Missing form data.");
}

$femail = $_POST['femail'];
$fcontact = $_POST['fcontact'];
$fstate = $_POST['fstate'];
$fno = $_POST['fno'];

$sql_check = $con->prepare("SELECT u_email FROM tb_user WHERE u_sno = ?");
$sql_check->bind_param("s", $fno);
$sql_check->execute();
$sql_check->store_result();

if ($sql_check->num_rows == 0) {
    displayAlertAndRedirect1("error", "Error", "User ID not found.");
}

$sql_check->bind_result($current_email);
$sql_check->fetch();
$sql_check->close();

$email_updated = false;
$contact_updated = false;

if ($current_email !== $femail) {
    $sql1 = $con->prepare("UPDATE tb_user SET u_email = ? WHERE u_sno = ?");
    $sql1->bind_param("ss", $femail, $fno);
    $sql1->execute();
    if ($sql1->affected_rows > 0) {
        $email_updated = true;
    }
    $sql1->close();
}

$sql2 = $con->prepare("UPDATE tb_student SET s_contact = ?, s_state = ? WHERE s_no = ?");
$sql2->bind_param("sss", $fcontact, $fstate, $fno);
$sql2->execute();
if ($sql2->affected_rows > 0) {
    $contact_updated = true;
}
$sql2->close();
$con->close();

if ($email_updated || $contact_updated) {
    displayAlertAndRedirect1("success", "Success", "Profile updated successfully.", "index.php");
} else {
    displayAlertAndRedirect1("info", "No Changes", "No changes were made to the profile.");
}
?>
