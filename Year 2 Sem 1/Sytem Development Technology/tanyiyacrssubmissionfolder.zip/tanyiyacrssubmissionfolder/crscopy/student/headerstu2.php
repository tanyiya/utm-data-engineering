<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Registration Portal</title>
    <link rel="icon" type="image/x-icon" href="../img/kuromi.ico">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>
<body>
    <div class="registration-container">
        <header class="registration-header">
            <h1>Course Registration Portal</h1>
            <div class="header-actions" style="padding-right:15px">
            <a href="index.php" class="link">Register Course</a>
                <button id="profile-btn" class="profile-btn">Profile</button>
                <button id="logout-btn" class="logout-btn">Logout</button>
            </div>
        </header>