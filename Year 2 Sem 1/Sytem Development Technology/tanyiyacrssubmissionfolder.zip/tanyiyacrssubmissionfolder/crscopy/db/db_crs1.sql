-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 27, 2025 at 11:10 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_crs1`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `a_no` varchar(10) NOT NULL,
  `a_name` varchar(255) NOT NULL,
  `a_contact` varchar(15) NOT NULL,
  `a_state` varchar(25) NOT NULL,
  `a_regtime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`a_no`, `a_name`, `a_contact`, `a_state`, `a_regtime`) VALUES
('A001', 'Puan Rohani', '0111234567', 'Johor', '2025-01-27 08:44:43'),
('A002', 'Kaedehara Kazuha', '0111234567', 'Johor', '2025-01-27 08:44:43'),
('A003', 'Lesser Lord Kusanali', '0111234567', 'Johor', '2025-01-27 08:44:43');

-- --------------------------------------------------------

--
-- Table structure for table `tb_course`
--

CREATE TABLE `tb_course` (
  `c_code` varchar(20) NOT NULL,
  `c_name` varchar(255) NOT NULL,
  `c_credit` int(11) NOT NULL,
  `c_type` int(11) NOT NULL,
  `c_description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_course`
--

INSERT INTO `tb_course` (`c_code`, `c_name`, `c_credit`, `c_type`, `c_description`) VALUES
('SECJ2013', 'Data Structure and Algorithm', 3, 1, 'This course emphasis on data structure concepts theoretically and practically with detail algorithms for each of data structure. Students will learn abstract data type concepts using class and apply the concept in the implementation of data structures. Apart from it, student will learn recursive concept as a programming style and algorithm efficiency analysis with Big O notation. Various sorting and searching techniques will be discussed as data structure operations. Analysis of each algorithm will also be explained. Further, students will be exposed to linear data structures such as linked lists, stack and queue. Non-linear data structures such as tree and binary search tree will be discussed. Along the course, students should be able to implement and apply the theory and concepts of data structure in the assignments and mini project which are conducted in group.'),
('SECP3204', 'Software Engineering (WBL)', 4, 1, 'This course is designed to give students an introduction to an engineering approach in the development of high-quality software systems. It will discuss the important software engineering concepts in the various types of the common software process models. The students will also learn the concepts and techniques used in each software development phase Including requirements engineering, software design and software testing. This course will also expose the students to utilizing object-oriented method (e.g. UML) and tools in analyzing and designing the software. At the end of this course, students are expected to be able to appreciate most of the common software engineering concepts and techniques as well as producing various software artifacts, documentations, and deliverables. This course requires students to collaborate with a selected industry by building a high-quality software system required by the industry. Students are required to apply the most suitable software approach and techniques learned in the course. The industry involved will also contribute to a portion of assessment for the system build.'),
('SECP3723', 'System Development Technology (WBL)', 3, 2, 'The main focus of this course is to provide a practical approach of systems analysis and designing skills for the students using a structured methodology. Hence, the course enables students to study information system requirements for any system application within an organizational context. The contents are organized in sequence, which are planning, analysis, designing and implementation phases. From the resulting output of the planning and analysis phase shall enable students to form input, output, and interface design. Students are required to work on a project, i.e., to develop a database application system, for a selected organization. In this project, students are required to work closely with the organization during the process of analysis, designing and implementing the system by using the learned techniques. At the end of the course, students shall be able to apply the knowledge of designing and developing a good information system for a real-world problem.');

-- --------------------------------------------------------

--
-- Table structure for table `tb_coursestatus`
--

CREATE TABLE `tb_coursestatus` (
  `status_id` int(11) NOT NULL,
  `status_desc` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_coursestatus`
--

INSERT INTO `tb_coursestatus` (`status_id`, `status_desc`) VALUES
(1, 'open'),
(2, 'full'),
(3, 'closed');

-- --------------------------------------------------------

--
-- Table structure for table `tb_coursetype`
--

CREATE TABLE `tb_coursetype` (
  `type_id` int(11) NOT NULL,
  `type_desc` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_coursetype`
--

INSERT INTO `tb_coursetype` (`type_id`, `type_desc`) VALUES
(1, 'Core Course'),
(2, 'Elective'),
(3, 'General');

-- --------------------------------------------------------

--
-- Table structure for table `tb_lecturer`
--

CREATE TABLE `tb_lecturer` (
  `l_no` varchar(10) NOT NULL,
  `l_name` varchar(255) NOT NULL,
  `l_contact` varchar(15) NOT NULL,
  `l_state` varchar(25) NOT NULL,
  `l_regtime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_lecturer`
--

INSERT INTO `tb_lecturer` (`l_no`, `l_name`, `l_contact`, `l_state`, `l_regtime`) VALUES
('L001', 'Prof. Madya. Dr. Haza Nuzly Bin Abdull Hamed', '0111234567', 'Johor', '2025-01-27 08:44:43'),
('L002', 'Dr. Zuraini binti Ali Shah', '0111234567', 'Johor', '2025-01-27 08:44:43'),
('L003', 'Dr. Aryati binti Bakri', '0111234567', 'Johor', '2025-01-27 08:44:43');

-- --------------------------------------------------------

--
-- Table structure for table `tb_offeredcourse`
--

CREATE TABLE `tb_offeredcourse` (
  `c_id` int(11) NOT NULL,
  `c_code` varchar(20) NOT NULL,
  `c_lec` varchar(10) DEFAULT NULL,
  `c_sem` int(11) NOT NULL,
  `c_section` int(11) NOT NULL,
  `c_status` int(11) NOT NULL,
  `c_maxstudent` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_offeredcourse`
--

INSERT INTO `tb_offeredcourse` (`c_id`, `c_code`, `c_lec`, `c_sem`, `c_section`, `c_status`, `c_maxstudent`) VALUES
(1, 'SECP3723', 'L001', 2, 1, 1, 30),
(2, 'SECJ2013', 'L002', 2, 1, 1, 30),
(3, 'SECP3204', 'L003', 1, 1, 1, 30),
(4, 'SECP3204', 'L001', 2, 2, 1, 30);

-- --------------------------------------------------------

--
-- Table structure for table `tb_registration`
--

CREATE TABLE `tb_registration` (
  `r_tid` int(11) NOT NULL,
  `r_student` varchar(10) NOT NULL,
  `r_course` varchar(20) NOT NULL,
  `r_sem` int(11) NOT NULL,
  `r_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_regstatus`
--

CREATE TABLE `tb_regstatus` (
  `status_id` int(11) NOT NULL,
  `status_desc` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_regstatus`
--

INSERT INTO `tb_regstatus` (`status_id`, `status_desc`) VALUES
(1, 'received'),
(2, 'approved'),
(3, 'rejected');

-- --------------------------------------------------------

--
-- Table structure for table `tb_sem`
--

CREATE TABLE `tb_sem` (
  `sem_id` int(11) NOT NULL,
  `semester` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_sem`
--

INSERT INTO `tb_sem` (`sem_id`, `semester`) VALUES
(1, '2023/2024 - 1'),
(2, '2023/2024 - 2'),
(3, '2024/2025 - 1');

-- --------------------------------------------------------

--
-- Table structure for table `tb_student`
--

CREATE TABLE `tb_student` (
  `s_no` varchar(10) NOT NULL,
  `s_name` varchar(255) NOT NULL,
  `s_contact` varchar(15) NOT NULL,
  `s_state` varchar(25) NOT NULL,
  `s_regtime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_student`
--

INSERT INTO `tb_student` (`s_no`, `s_name`, `s_contact`, `s_state`, `s_regtime`) VALUES
('S001', 'Tan Yi Ya', '0183823002', 'Pulau Pinang', '2025-01-27 08:44:43'),
('S002', 'Liew Yng Jeng', '01113005550', 'Johor', '2025-01-27 08:44:43'),
('S003', 'Teh Ru Qian', '0197312411', 'Melaka', '2025-01-27 08:44:43');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `u_sno` varchar(10) NOT NULL,
  `u_email` varchar(255) NOT NULL,
  `u_pwd` varchar(255) NOT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `token_expiry` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `u_utype` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`u_sno`, `u_email`, `u_pwd`, `reset_token`, `token_expiry`, `u_utype`) VALUES
('A001', 'rohani@gmail.com', '$argon2id$v=19$m=16,t=2,p=1$TTI5eHU4TWpCWXd1Tllsdg$ZRj93tHbkJmyBn69e8BgDQ', NULL, '2025-01-27 08:40:10', 3),
('A002', 'kazuha@gmail.com', '$argon2id$v=19$m=16,t=2,p=1$TTI5eHU4TWpCWXd1Tllsdg$ZRj93tHbkJmyBn69e8BgDQ', NULL, '2025-01-27 08:39:58', 3),
('A003', 'nahida@gmail.com', '$argon2id$v=19$m=16,t=2,p=1$TTI5eHU4TWpCWXd1Tllsdg$ZRj93tHbkJmyBn69e8BgDQ', NULL, '2025-01-27 08:39:46', 3),
('L001', 'haza@utm.my', '$argon2id$v=19$m=16,t=2,p=1$TTI5eHU4TWpCWXd1Tllsdg$ZRj93tHbkJmyBn69e8BgDQ', NULL, '2025-01-27 08:38:29', 1),
('L002', 'aszuraini@utm.my', '$argon2id$v=19$m=16,t=2,p=1$TTI5eHU4TWpCWXd1Tllsdg$ZRj93tHbkJmyBn69e8BgDQ', NULL, '2025-01-27 08:38:29', 1),
('L003', 'aryati@utm.my', '$argon2id$v=19$m=16,t=2,p=1$TTI5eHU4TWpCWXd1Tllsdg$ZRj93tHbkJmyBn69e8BgDQ', NULL, '2025-01-27 08:38:29', 1),
('S001', 'tanyiya@gmail.com', '$argon2id$v=19$m=16,t=2,p=1$TTI5eHU4TWpCWXd1Tllsdg$ZRj93tHbkJmyBn69e8BgDQ', NULL, '2025-01-27 08:38:29', 2),
('S002', 'yngjeng@gmail.com', '$argon2id$v=19$m=16,t=2,p=1$TTI5eHU4TWpCWXd1Tllsdg$ZRj93tHbkJmyBn69e8BgDQ', NULL, '2025-01-27 08:38:29', 2),
('S003', 'ruqian@gmail.com', '$argon2id$v=19$m=16,t=2,p=1$TTI5eHU4TWpCWXd1Tllsdg$ZRj93tHbkJmyBn69e8BgDQ', NULL, '2025-01-27 08:38:29', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tb_utype`
--

CREATE TABLE `tb_utype` (
  `type_id` int(11) NOT NULL,
  `type_desc` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_utype`
--

INSERT INTO `tb_utype` (`type_id`, `type_desc`) VALUES
(1, 'Lecturer'),
(2, 'Student'),
(3, 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`a_no`);

--
-- Indexes for table `tb_course`
--
ALTER TABLE `tb_course`
  ADD PRIMARY KEY (`c_code`),
  ADD KEY `c_type` (`c_type`);

--
-- Indexes for table `tb_coursestatus`
--
ALTER TABLE `tb_coursestatus`
  ADD PRIMARY KEY (`status_id`);

--
-- Indexes for table `tb_coursetype`
--
ALTER TABLE `tb_coursetype`
  ADD PRIMARY KEY (`type_id`);

--
-- Indexes for table `tb_lecturer`
--
ALTER TABLE `tb_lecturer`
  ADD PRIMARY KEY (`l_no`);

--
-- Indexes for table `tb_offeredcourse`
--
ALTER TABLE `tb_offeredcourse`
  ADD PRIMARY KEY (`c_id`),
  ADD KEY `c_code` (`c_code`),
  ADD KEY `c_lec` (`c_lec`),
  ADD KEY `c_status` (`c_status`),
  ADD KEY `c_sem` (`c_sem`);

--
-- Indexes for table `tb_registration`
--
ALTER TABLE `tb_registration`
  ADD PRIMARY KEY (`r_tid`),
  ADD KEY `r_student` (`r_student`),
  ADD KEY `r_course` (`r_course`),
  ADD KEY `r_status` (`r_status`),
  ADD KEY `r_sem` (`r_sem`);

--
-- Indexes for table `tb_regstatus`
--
ALTER TABLE `tb_regstatus`
  ADD PRIMARY KEY (`status_id`);

--
-- Indexes for table `tb_sem`
--
ALTER TABLE `tb_sem`
  ADD PRIMARY KEY (`sem_id`);

--
-- Indexes for table `tb_student`
--
ALTER TABLE `tb_student`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`u_sno`),
  ADD KEY `u_utype` (`u_utype`);

--
-- Indexes for table `tb_utype`
--
ALTER TABLE `tb_utype`
  ADD PRIMARY KEY (`type_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_offeredcourse`
--
ALTER TABLE `tb_offeredcourse`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tb_registration`
--
ALTER TABLE `tb_registration`
  MODIFY `r_tid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_sem`
--
ALTER TABLE `tb_sem`
  MODIFY `sem_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD CONSTRAINT `tb_admin_ibfk_1` FOREIGN KEY (`a_no`) REFERENCES `tb_user` (`u_sno`);

--
-- Constraints for table `tb_course`
--
ALTER TABLE `tb_course`
  ADD CONSTRAINT `tb_course_ibfk_1` FOREIGN KEY (`c_type`) REFERENCES `tb_coursetype` (`type_id`);

--
-- Constraints for table `tb_lecturer`
--
ALTER TABLE `tb_lecturer`
  ADD CONSTRAINT `tb_lecturer_ibfk_1` FOREIGN KEY (`l_no`) REFERENCES `tb_user` (`u_sno`);

--
-- Constraints for table `tb_offeredcourse`
--
ALTER TABLE `tb_offeredcourse`
  ADD CONSTRAINT `tb_offeredcourse_ibfk_1` FOREIGN KEY (`c_code`) REFERENCES `tb_course` (`c_code`),
  ADD CONSTRAINT `tb_offeredcourse_ibfk_2` FOREIGN KEY (`c_lec`) REFERENCES `tb_lecturer` (`l_no`),
  ADD CONSTRAINT `tb_offeredcourse_ibfk_3` FOREIGN KEY (`c_status`) REFERENCES `tb_coursestatus` (`status_id`),
  ADD CONSTRAINT `tb_offeredcourse_ibfk_4` FOREIGN KEY (`c_sem`) REFERENCES `tb_sem` (`sem_id`);

--
-- Constraints for table `tb_registration`
--
ALTER TABLE `tb_registration`
  ADD CONSTRAINT `tb_registration_ibfk_1` FOREIGN KEY (`r_student`) REFERENCES `tb_student` (`s_no`),
  ADD CONSTRAINT `tb_registration_ibfk_2` FOREIGN KEY (`r_course`) REFERENCES `tb_course` (`c_code`),
  ADD CONSTRAINT `tb_registration_ibfk_3` FOREIGN KEY (`r_status`) REFERENCES `tb_regstatus` (`status_id`),
  ADD CONSTRAINT `tb_registration_ibfk_4` FOREIGN KEY (`r_sem`) REFERENCES `tb_sem` (`sem_id`);

--
-- Constraints for table `tb_student`
--
ALTER TABLE `tb_student`
  ADD CONSTRAINT `tb_student_ibfk_1` FOREIGN KEY (`s_no`) REFERENCES `tb_user` (`u_sno`);

--
-- Constraints for table `tb_utype`
--
ALTER TABLE `tb_utype`
  ADD CONSTRAINT `tb_utype_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `tb_user` (`u_utype`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
