<?php
include('headerlec.php');
include('../db-connect.php');

include('../crs_session.php');
if(!session_id())
{
  session_start();
}
if ($_SESSION['u_utype'] != 1) {
  header('Location: ../login');
  exit();
}

if (!isset($_SESSION['u_sno'])) {
    header('Location: ../login');
    exit();
}

if(isset($_SESSION['u_sno'])) {
    $profilequery = "SELECT * FROM tb_lecturer WHERE l_no = '{$_SESSION['u_sno']}'";
    $profile_result = mysqli_query($con, $profilequery);
    $lecturer = mysqli_fetch_assoc($profile_result);
    //var_dump($lecturer);
    $emailquery = "SELECT u_email FROM tb_user WHERE u_sno = '{$_SESSION['u_sno']}'";
    $email_result = mysqli_query($con, $emailquery);
    $email = mysqli_fetch_assoc($email_result);
    //var_dump($email);
}
?>

        <main class="dashboard-main">
            <section class="assigned-courses-section">
                <h4 style="margin-left: 8px">Assigned Courses</h4>
                <div class="semester-filter">
                    <select id="semester-select">
                    <?php
                    $semester_query = "SELECT * FROM tb_sem";
                    $semester_result = mysqli_query($con, $semester_query);

                    while ($semester = mysqli_fetch_assoc($semester_result)) {
                        $selected = (isset($_GET['filter_semester']) && $_GET['filter_semester'] == $semester['sem_id']) ? 'selected' : '';
                        echo "<option value='{$semester['sem_id']}' $selected>{$semester['semester']}</option>";
                    }
                    ?>
                    </select>
                </div>
                <div id="course-list" class="course-list">
                    <!-- Courses -->
                </div>
            </section>

            <section class="course-details-section" id="course-details-section">
                <!-- Course explaination -->
            </section>
        </main>
    </div>

<!-- Profile Modal -->
<div id="profile-modal" class="modal">
        <div class="modal-content">
        <div class="modal-header">
        <span class="close-modal">&times;</span>
        <h2>Lecturer Profile</h2>
        </div>
            <form id="profile-form" method="POST" action="update_profile.php"> 
                <div class="form-group">
                    <label for="full-name">Full Name</label>
                    <input type="text" id="full-name" name="fname" value="<?php echo $lecturer['l_name']; ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="staff-number">Staff Number</label>
                    <input type="text" id="fno" name="fno" value="<?php echo $lecturer['l_no']; ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="femail">Email</label>
                    <input type="email" id="femail" name="femail" value="<?php echo $email['u_email']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="fcontact">Contact Number</label>
                    <input type="tel" id="fcontact" name="fcontact" value="<?php echo $lecturer['l_contact']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="fstate">State</label>
                    <input type="text" id="fstate" name="fstate" value="<?php echo $lecturer['l_state']; ?>" required>
                </div>
                <button type="submit" class="save-profile-btn">Update Profile</button>
            </form>
        </div>
    </div>

    <script>
document.addEventListener('DOMContentLoaded', () => {
    const courseList = document.getElementById('course-list');
    const courseDetailsSection = document.getElementById('course-details-section');
    const semesterSelect = document.getElementById('semester-select');
    const lecturerNo = "<?php echo $_SESSION['u_sno']; ?>"; 

        // Profile Modal Functionality
    const profileBtn = document.getElementById('profile-btn');
    const profileModal = document.getElementById('profile-modal');
    const closeProfileModal = profileModal.querySelector('.close-modal');
    const profileForm = document.getElementById('profile-form');

    profileBtn.addEventListener('click', () => {
        profileModal.style.display = 'block';
    });

    closeProfileModal.addEventListener('click', () => {
        profileModal.style.display = 'none';
    });


    document.getElementById('logout-btn').addEventListener('click', function(event) {
            event.preventDefault();
            Swal.fire({
                title: 'Are you sure?',
                text: "Do you want to log out?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, log out!'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '../logout.php';
                }
            });
        });
        
    semesterSelect.addEventListener('change', (e) => {
        fetchCourses(e.target.value); // This passes the selected semester ID (sem_id)
    });

    // Initially fetch courses if a semester is selected
    if (semesterSelect.value) {
        fetchCourses(semesterSelect.value);
    }

    // Fetch courses based on selected semester
    async function fetchCourses(semester) {
        try {
            const response = await fetch(`fetch_course.php?lecturer_no=${lecturerNo}&semester=${semester}`);
            const courses = await response.json();

            if (courses.length === 0) {
                courseList.innerHTML = "<p>No courses found for the selected semester.</p>";
            } else {
                renderCourses(courses);
            }
        } catch (error) {
            console.error("Error fetching courses:", error);
        }
    }

    // Render courses for selected semester
    function renderCourses(courses) {
        courseList.innerHTML = courses.map(course => `
            <div class="course-item" data-code="${course.code}">
                <h5><strong>${course.code}</strong></h5>
                <p><h5>${course.name}</h5></p>
                <p><strong>Credits:</strong> ${course.credits}</p>
            </div>
        `).join('');

        courseList.querySelectorAll('.course-item').forEach(item => {
            item.addEventListener('click', () => {
                const courseCode = item.dataset.code;
                const course = courses.find(c => c.code === courseCode);
                renderCourseDetails(course, courseCode);
            });
        });
    }

    // Render course details and fetch student details
    function renderCourseDetails(course, courseCode) {
        courseDetailsSection.innerHTML = `
            <div class="course-details">
                <h4>${course.code} - ${course.name}</h4>
                <p>${course.description}</p>
                <p><strong>Credits:</strong> ${course.credits}</p>
                <p><strong>Sections:</strong> ${course.section}</p>
            </div>
            <h3>Student List</h3>
            <div id="student-list-container">
                <p>Loading students...</p>
            </div>
        `;

        // Fetch student details for the selected course
        fetchStudentDetails(courseCode, course.section);
    }

    // Fetch student details when a course is clicked
    async function fetchStudentDetails(courseCode, courseSection) {
        try {
            const response = await fetch(`fetch_students.php?course_code=${courseCode}&course_section=${courseSection}`);
            const students = await response.json();

            if (students.length > 0) {
                renderStudentDetails(students);
            } else {
                document.getElementById('student-list-container').innerHTML = "<p>No students registered for this course.</p>";
            }
        } catch (error) {
            console.error("Error fetching student details:", error);
        }
    }

    // Render student details
    function renderStudentDetails(students) {
        const studentListContainer = document.getElementById('student-list-container');
        studentListContainer.innerHTML = `
            <table class="student-list">
                <thead>
                    <tr>
                        <th>Student Name</th>
                        <th>Student ID</th>
                        <th>Email</th>
                        <th>Contact Number</th>
                        <th>State</th>
                    </tr>
                </thead>
                <tbody>
                    ${students.map(student => `
                        <tr data-student-id="${student.id}">
                            <td>${student.name}</td>
                            <td>${student.student_no}</td>
                            <td>${student.email}</td>
                            <td>${student.contact}</td>
                            <td>${student.state}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;

    }


    // Initial course rendering
    if (semesterSelect.value) {
        fetchCourses(semesterSelect.value);
    }
});
</script>
</body>
</html>
