<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Registration System - Lecturer</title>
    <link rel="icon" type="image/x-icon" href="../img/kuromi.ico">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>

<?
include('../loginfunction.php');
?>

<div class="lecturer-dashboard">
    <header class="dashboard-header">
        <div class="header-content" style="display: flex; align-items: center; justify-content: space-between;">
            <h2 style="margin: 0; padding-left: 15px">Lecturer Dashboard</h2>
            <div class="header-actions" style="padding-right:15px">
                <button id="profile-btn" class="profile-btn">Profile</button>
                <button id="logout-btn" class="logout-btn">Logout</button>
            </div>
        </div>

    </header>