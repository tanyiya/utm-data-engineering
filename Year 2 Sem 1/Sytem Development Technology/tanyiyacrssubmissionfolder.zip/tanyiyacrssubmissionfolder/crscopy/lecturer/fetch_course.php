<?php
// Database connection
include('../db-connect.php');

// Ensure the parameters are received correctly
if (!isset($_GET['semester']) || !isset($_GET['lecturer_no'])) {
    echo json_encode(['error' => 'Invalid semester or lecturer number.']);
    exit;
}

$semester = $_GET['semester'];  // Semester passed as a query parameter
$lecturerNo = $_GET['lecturer_no'];  // Lecturer's number passed as a query parameter

// Query to get courses for the selected semester and lecturer
$sql = "
    SELECT 
        c.c_code, c.c_name, c.c_description, c.c_credit, o.c_section
    FROM tb_course c
    JOIN tb_offeredcourse o ON c.c_code = o.c_code
    WHERE o.c_lec = ? AND o.c_sem = ?
";

$stmt = $con->prepare($sql);
$stmt->bind_param("si", $lecturerNo, $semester);
$stmt->execute();
$result = $stmt->get_result();

$courses = [];
while ($row = $result->fetch_assoc()) {
    $courses[] = [
        'code' => $row['c_code'],
        'name' => $row['c_name'],
        'description' => $row['c_description'],
        'credits' => $row['c_credit'],
        'section' => $row['c_section'],
    ];
}



// Close connection
$con->close();

// Return the courses as JSON
echo json_encode($courses);
?>
