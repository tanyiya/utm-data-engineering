<?php
include('../login/header.php');
?>

<body class="auth-body">
    <div class="auth-container" style="margin-top: 50px; margin-bottom: 50px;">
        <div class="auth-wrapper">      
            <div class="auth-form-container" id="register-container">  
                <form id="register-form" class="auth-form" method="post" action="registerprocess.php">
                    <h2>Create Account</h2>
                    <div class="form-group">
                        <label for="register-userid">Staff/Student ID</label>
                        <input type="text" name="funame" required>
                    </div>
                    <div class="form-group">
                        <label for="register-email">Email</label>
                        <input type="email" name="femail" required>
                    </div>
                    <div class="form-group">
                        <label for="register-fullname">Full Name</label>
                        <input type="text" name="fname" required>
                    </div>
                    <div class="form-group">
                        <label for="register-contact">Contact Number</label>
                        <input type="tel" name="ftelno" required>
                    </div>
                    <div class="form-group">
                        <label for="register-state">State</label>
                        <select name="fstate" required>
                            <option value=""></option>
                            <option value="Johor">Johor</option>
                            <option value="Kedah">Kedah</option>
                            <option value="Kelantan">Kelantan</option>
                            <option value="Melaka">Melaka</option>
                            <option value="Negeri Sembilan">Negeri Sembilan</option>
                            <option value="Pahang">Pahang</option>
                            <option value="Perak">Perak</option>
                            <option value="Perlis">Perlis</option>
                            <option value="Pulau Pinang">Pulau Pinang</option>
                            <option value="Sabah">Sabah</option>
                            <option value="Sarawak">Sarawak</option>
                            <option value="Selangor">Selangor</option>
                            <option value="Terengganu">Terengganu</option>
                            <option value="Wilayah Persekutuan">Wilayah Persekutuan</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="register-state">Select your role:</label>
                        <select name="futype" required>
                            <option value=""></option>
                            <option value="1">Lecturer</option>
                            <option value="2">Student</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="register-password">Password</label>
                        <input type="password" name="fpwd" required>
                    </div>
                    <div class="form-group">
                        <label for="confirm-password">Confirm Password</label>
                        <input type="password" name="confirmfpwd" required>
                    </div>
                    <button type="submit" class="auth-submit-btn" id="save-btn">Register</button>
                    <div class="auth-switch">
                        <p>Already have an account?</p>
                        <button type="button" id="switch-to-login" class="switch-btn" onclick="location.href='../login'">Login</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    </div>

</body>
    