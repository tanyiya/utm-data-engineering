<?php
// Connect to DB
include('../db-connect.php');
include('../login/loginfunction.php');

if ($con) {
    include 'index.php';
} else {
    echo "Failed to connect to the database.";
}

// Function to display SweetAlert and redirect
function displayAlertAndRedirect($type, $title, $message, $redirect = null) {
    echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
    echo "<script>
        Swal.fire({
            icon: '$type',
            title: '$title',
            text: '$message',
            confirmButtonText: 'OK'
        }).then((result) => {
            if (result.isConfirmed && '$redirect') {
                window.location.href = '$redirect';
            }
        });
    </script>";
    exit;
}

if ($_POST) {
    $cleanPost = cleanPost($_POST);

    // Get input values
    $funame = $cleanPost['funame'];
    $femail = $cleanPost['femail'];
    $fname = $cleanPost['fname'];
    $fcontact = $cleanPost['ftelno'];
    $fstate = $cleanPost['fstate'];
    $futype = $cleanPost['futype'];
    $Password = $cleanPost['fpwd'];
    $confirmPassword = $cleanPost['confirmfpwd'];

    // Check if passwords match
    if ($Password !== $confirmPassword) {
        displayAlertAndRedirect("error", "Error", "Passwords do not match.");
    }

    // Hash the password
    $hashedPassword = password_hash($Password, PASSWORD_DEFAULT);

    // Start a database transaction
    $con->begin_transaction();

    try {
        // Insert into tb_user
        $stmt = $con->prepare("
            INSERT INTO tb_user (u_sno, u_email, u_pwd, u_utype)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->bind_param("sssi", $funame, $femail, $hashedPassword, $futype);
        $stmt->execute();

        // Insert into the role-specific table
        if ($futype == 1) {
            // Lecturer
            $stmt = $con->prepare("
                INSERT INTO tb_lecturer (l_no, l_name, l_contact, l_state)
                VALUES (?, ?, ?, ?)
            ");
        } elseif ($futype == 2) {
            // Student
            $stmt = $con->prepare("
                INSERT INTO tb_student (s_no, s_name, s_contact, s_state)
                VALUES (?, ?, ?, ?)
            ");
        } else {
            throw new Exception("Invalid user type.");
        }

        // Bind and execute the role-specific query
        $stmt->bind_param("ssss", $funame, $fname, $fcontact, $fstate);
        $stmt->execute();

        // Commit the transaction
        $con->commit();

        // Success message with redirect
        displayAlertAndRedirect("success", "Success", "Registration completed successfully.", "../login");

    } catch (Exception $e) {
        // Rollback on error
        $con->rollback();
        displayAlertAndRedirect("error", "Registration Failed", $e->getMessage());
    } finally {
        // Close the statement and connection
        if (isset($stmt)) {
            $stmt->close();
        }
        $con->close();
    }
} else {
    displayAlertAndRedirect("warning", "Warning", "Invalid request.");
}
?>
