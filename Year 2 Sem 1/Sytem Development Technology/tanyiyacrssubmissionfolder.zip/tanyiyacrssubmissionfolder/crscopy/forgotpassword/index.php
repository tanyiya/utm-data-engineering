<?php include 'header.php';?>

<body class="auth-body">
    <div class="auth-container">
        <div class="auth-wrapper">
            <div class="auth-form-container" id="login-container">
                <form method="post" class= "auth-form" action = "forgotpwprocess.php">
                    <h2>Send Confirmation Email</h2>
                    <div class="form-group">
                        <label>User ID</label>
                        <input type="text" id="funame" name="funame" placeholder="Staff ID/Student ID" required>
                    </div>
                    <div class="form-group password-group">
                        <label for="login-password">Email</label>
                        <input type="email" id="femail" name="femail" placeholder="abc@example.com" required>
                    </div>
                    <button type="submit" class="auth-submit-btn">Enter</button>
                    <div class="auth-switch">
                        <p>Don't have an account?</p>
                        <button type="button" class="switch-btn">Register</button>
                    </div>
                </form>
            </div>          
        </div>
    </div>
</body>

