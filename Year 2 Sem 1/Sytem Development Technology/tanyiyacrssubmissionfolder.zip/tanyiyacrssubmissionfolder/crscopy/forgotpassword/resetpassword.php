<?php

include 'header.php';
include('../db-connect.php');

// Define the SweetAlert script (only once in the head)
$sweetAlertScript = '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>';

$alertMessage = ''; // Variable to store SweetAlert message
$redirectToLogin = false; // Flag for redirection

if (isset($_GET['token']) || isset($_POST['token'])) {
    // Use the token from the URL or POST
    $token = isset($_POST['token']) ? $_POST['token'] : $_GET['token'];

    // Check if the token exists in the database and is not expired
    $sql = "SELECT * FROM tb_user WHERE reset_token = ?";
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, 's', $token);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($result);

    if ($user) {
        // Token found, check if it has expired
        $currentTime = new DateTime();
        $expiryTime = new DateTime($user['token_expiry']);

        // Compare the current time with the expiry time
        if ($currentTime < $expiryTime) {
            // Token is valid and not expired, display the reset password form
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                // Get the new password and confirmation password
                $newPassword = $_POST['new_password'];
                $confirmPassword = $_POST['confirm_password'];

                if ($newPassword === $confirmPassword) {
                    // Hash the new password
                    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

                    // Update the password in the database and clear the reset token
                    $sql = "UPDATE tb_user SET u_pwd = ?, reset_token = NULL, token_expiry = NULL WHERE reset_token = ?";
                    $stmt = mysqli_prepare($con, $sql);
                    mysqli_stmt_bind_param($stmt, 'ss', $hashedPassword, $token);
                    mysqli_stmt_execute($stmt);

                    // Success message and redirection flag
                    $alertMessage = "Password changed successfully.";
                    $redirectToLogin = true;
                } else {
                    // Error message if passwords don't match
                    $alertMessage = "Password must be the same in both fields!";
                }
            }
        } else {
            // Token has expired
            $alertMessage = "Token expired.";
        }
    } else {
        // Token not found in the database
        $alertMessage = "Token does not exist.";
    }
} else {
    echo "<p>No token provided.</p>";
}
?>

    <body class="auth-body">
    <div class="auth-container">
        <div class="auth-wrapper">
            <div class="auth-form-container" id="login-container">
            <?php if (isset($user)) : ?>
                <form method="post" class= "auth-form" action = "resetpassword.php">
                    <h2>Reset Password</h2>
                    <input type="hidden" name="token" value="<?php echo $token; ?>">
                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" id="funame" name="new_password" required>
                    </div>
                    <div class="form-group password-group">
                        <label for="login-password">Confirm Password</label>
                        <input type="password" id="femail" name="confirm_password" required>
                    </div>
                    <button type="submit" class="auth-submit-btn">Enter</button>
                </form>
                <?php else : ?>
                    <p class="text-center">Invalid token.</p>
                <?php endif; ?>
            </div>          
        </div>
    </div>
</body>

    <?php if ($alertMessage): ?>
        <!-- Only echo SweetAlert if there's a message -->
        <script>
            Swal.fire({
                icon: '<?php echo $redirectToLogin ? "success" : "error"; ?>',
                title: '<?php echo $alertMessage; ?>',
            }).then(() => {
                <?php if ($redirectToLogin): ?>
                    window.location.href = '../login'; // Redirect after success
                <?php endif; ?>
            });
        </script>
    <?php endif; ?>
</body>
</html>
