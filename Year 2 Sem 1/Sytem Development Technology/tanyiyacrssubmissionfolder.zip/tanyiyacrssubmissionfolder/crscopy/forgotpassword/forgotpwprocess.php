<?php
date_default_timezone_set('Asia/Kuala_Lumpur');  
include('../login/loginfunction.php');
// Connect to DB
include('../db-connect.php');
if ($con) {
    include 'index.php';
} else {
    echo "Failed to connect to the database.";
}

if ($_POST) {
    $cleanPost = cleanPost($_POST);
    
    $userID = $cleanPost['funame'];
    $email = $cleanPost['femail'];

    // Check database for matching ID and email
    $sql = "SELECT u_sno, u_email 
            FROM tb_user
            WHERE u_sno = ? AND u_email = ?";
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, 'ss', $userID, $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) > 0) {
        // If match found, generate a unique token
        $token = bin2hex(random_bytes(16)); // Generates a random 16-byte token
        $expiryTime = date("Y-m-d H:i:s", strtotime("+10 minutes", time()));
        $sql = "UPDATE tb_user SET reset_token = ?, token_expiry = ? WHERE u_sno = ?";
        $stmt = mysqli_prepare($con, $sql);
        mysqli_stmt_bind_param($stmt, 'sss', $token, $expiryTime, $userID);
        mysqli_stmt_execute($stmt);

        // Create the reset password link with the token
        $resetLink = "http://127.0.0.1/crs/forgotpassword/resetpassword.php?token=$token";

        //  send email
        $subject = "Reset Your Password";
        $message = "Click this link to reset your password: $resetLink Note: The link will only be valid for 10 minutes.";

        if (send_email($email, $subject, $message)) {
            echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
            echo "<script>
                Swal.fire({
                    icon: 'success',
                    title: 'Email Sent successfully',
                    text: 'A password reset email has been sent to $email.'
                });
            </script>";

        } else {
            echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
            echo "<script>
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Something was wrong..'
                });
            </script>";
        }
    } else {
        echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
        echo "<script>
            Swal.fire({
                icon: 'error',
                title: 'User ID and email does not match!',
            });
        </script>";
    }

    exit;
}
?>
