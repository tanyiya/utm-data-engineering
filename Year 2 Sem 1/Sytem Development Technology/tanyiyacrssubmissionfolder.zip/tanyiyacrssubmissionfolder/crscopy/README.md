# crs
 Course Registration System

27/1 User authentication done

28/1 5:13pm Lecturer page done partially 
- include function to view assigned course and students

