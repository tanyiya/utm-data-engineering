<?php 
header('Location: login');
?>
